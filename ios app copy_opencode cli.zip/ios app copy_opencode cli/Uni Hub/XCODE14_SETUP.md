# 📝 Setup Guide for Xcode 14.2

## ⚠️ Important: Xcode 14.2 Has Different UI

The "Configurations" section doesn't appear in Build Settings for Xcode 14.2. That's OK - we'll use a simpler method!

---

## ✅ What I Already Did For You

I've already modified the project file (`project.pbxproj`) to include the `SecurityConfiguration.xcconfig` file. This means you don't need to manually configure it in Xcode!

---

## 🔑 What YOU Need To Do (Super Simple!)

### **Step 1: Add Your Resend API Key**

1. In Xcode, open this file:
   ```
   Uni Hub/Uni Hub/SecurityConfiguration.xcconfig
   ```

2. Find this line (line 9):
   ```xcconfig
   RESEND_API_KEY = re_YOUR_ACTUAL_API_KEY_HERE
   ```

3. Replace it with your actual Resend API key:
   ```xcconfig
   RESEND_API_KEY = re_AbCdEfGhIjKlMnOpQrStUvWxYz123456
   ```

4. **Save the file** (Cmd + S)

---

### **Step 2: Get Your Free Resend API Key** (if you haven't already)

1. Go to: **https://resend.com**
2. Click **"Sign Up"** (top right)
3. Sign up with your email
4. Verify your email address
5. Go to **"API Keys"** in the dashboard
6. Copy your API key (starts with `re_`)

---

### **Step 3: Run the App!**

1. In Xcode, press **Cmd + R** to build and run
2. The app will automatically load your API key from the config file
3. Test the signup flow - you should get OTP emails! 📧

---

## 🎯 How It Works Now

Instead of using Xcode's Build Settings configuration (which is different in 14.2), the app now:

1. **Reads the `.xcconfig` file directly** from the bundle
2. **Parses the API key** from the file content
3. **Gives clear error messages** if the key isn't configured

This works in ALL Xcode versions! ✅

---

## 🔍 Troubleshooting

### Error: "RESEND_API_KEY not configured"

**Cause:** You haven't added your API key yet, or it's still the placeholder value.

**Fix:**
1. Open `SecurityConfiguration.xcconfig`
2. Make sure line 9 has your REAL API key (not the placeholder)
3. Save the file
4. Clean build folder: **Shift + Cmd + K**
5. Run again: **Cmd + R**

### Email Not Sending

**Check:**
1. Is your API key correct? (should start with `re_`)
2. Do you have internet connection?
3. Check Resend dashboard at https://resend.com/dashboard

### Can't Find SecurityConfiguration.xcconfig in Xcode

**Solution:**
1. In Xcode, go to **File → Add Files to "Uni Hub"...**
2. Navigate to: `Uni Hub/Uni Hub/SecurityConfiguration.xcconfig`
3. Click **Add**
4. Make sure "Copy items if needed" is UNCHECKED
5. Click **Add**

---

## 📁 File Structure

```
Uni Hub/
├── Uni Hub.xcodeproj/
│   └── project.pbxproj          ← Modified to include xcconfig
├── Uni Hub/
│   ├── SecurityConfiguration.xcconfig  ← ADD YOUR KEY HERE!
│   └── Services/
│       └── Email/
│           └── EmailService.swift      ← Reads the config file
```

---

## 🎉 That's It!

No complex Xcode configuration needed. Just:
1. Add your API key to `SecurityConfiguration.xcconfig`
2. Run the app!

For more details about Resend setup, see:
- `SETUP_RESEND.md` - Complete Resend guide
- `SECURITY_GUIDE.md` - Security best practices

---

**Questions?** The error message will tell you exactly what's wrong if something isn't configured! 😊
