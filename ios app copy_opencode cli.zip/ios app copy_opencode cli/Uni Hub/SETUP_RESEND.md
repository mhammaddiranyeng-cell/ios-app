# 🚀 Resend Email Setup Guide

## Why Resend?
- ✅ **Free Tier**: 3,000 emails/month (100/day) - perfect for MVP!
- ✅ **Excellent Deliverability**: Emails actually arrive in inbox (not spam)
- ✅ **Fast Delivery**: OTPs arrive in seconds
- ✅ **Beautiful Templates**: HTML email support
- ✅ **Easy Setup**: No complex SMTP configuration

---

## Step 1: Get Your Free API Key

1. Go to **[https://resend.com](https://resend.com)**
2. Click **"Sign Up"** (top right)
3. Sign up with your email (use a real email you can access)
4. Verify your email address
5. Go to **API Keys** section in dashboard
6. Copy your API key (starts with `re_`)

---

## Step 2: Add Your API Key Securely

### 🔒 **SECURE METHOD (Recommended)**

1. In Xcode, navigate to: `Uni Hub/Uni Hub/SecurityConfiguration.xcconfig`
2. Find line 9:
   ```xcconfig
   RESEND_API_KEY = re_YOUR_ACTUAL_API_KEY_HERE
   ```
3. Replace with your actual key:
   ```xcconfig
   RESEND_API_KEY = re_AbCdEfGhIjKlMnOpQrStUvWxYz123456
   ```

**Why this is better:**
- ✅ API key is NOT in your source code
- ✅ Won't be committed to Git
- ✅ Follows iOS security best practices
- ✅ Easy to use different keys for Dev/Prod

### ⚙️ Configure Xcode Project

1. Open your Xcode project
2. Click on **"Uni Hub"** project file (blue icon)
3. Select **"Uni Hub"** target
4. Go to **"Build Settings"** tab
5. Search for **"Configurations"**
6. For both **Debug** and **Release**, choose: **SecurityConfiguration**

### ℹ️ Update Info.plist

1. In Xcode, open `Info.plist`
2. Right-click → **Add Row**
3. Key: `RESEND_API_KEY`
4. Type: `String`
5. Value: `$(RESEND_API_KEY)`

---

### ❌ OLD METHOD (Not Recommended - Only for Quick Testing)

If you absolutely must hardcode the key (NOT recommended):

1. Open `Uni Hub/Services/Email/EmailService.swift`
2. Line 7, replace:
   ```swift
   private let resendAPIKey: String = {
       guard let apiKey = Bundle.main.object(forInfoDictionaryKey: "RESEND_API_KEY") as? String
       else { fatalError("Not configured") }
       return apiKey
   }()
   ```
   
   With (TEMPORARY ONLY):
   ```swift
   private let resendAPIKey = "re_YOUR_ACTUAL_KEY"
   ```

⚠️ **WARNING**: This is insecure! Use only for quick testing, then switch back to the secure method above.

---

## Step 3: Update Database Schema

You need to add these fields to your Supabase `users` table:

### SQL Migration (run in Supabase SQL Editor):

```sql
-- Add password_hash and is_verified columns if they don't exist
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS password_hash TEXT,
ADD COLUMN IF NOT EXISTS is_verified BOOLEAN DEFAULT FALSE;

-- Create index for faster email lookups
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
```

---

## Step 4: Test It!

1. Run the app in Xcode
2. Click "Sign in with Email"
3. Enter your email and a password (6+ characters)
4. Click "Create Account"
5. **Check your email inbox** (and spam folder just in case)
6. You should receive a beautiful OTP email within seconds! 📧
7. Enter the 6-digit code
8. You're logged in! ✅

---

## Email Template Preview

The OTP email looks like this:

```
┌─────────────────────────────────────┐
│   Welcome to Student Hub!           │  ← Blue gradient header
├─────────────────────────────────────┤
│                                     │
│ Hello,                              │
│                                     │
│ Thanks for signing up!              │
│                                     │
│ Your verification code is:          │
│ ┌─────────────────────────────┐    │
│ │        1 2 3 4 5 6          │    │  ← Large blue code
│ └─────────────────────────────┘    │
│                                     │
│ This code will expire in 10 min.    │
│                                     │
│ Student Hub Lebanon                 │
│ Connecting Students Everywhere      │
└─────────────────────────────────────┘
```

---

## Troubleshooting

### ❌ "Failed to send email"
- Check your Resend API key is correct
- Make sure you have internet connection
- Check Resend dashboard for errors

### ❌ Email not arriving
- Check spam/junk folder
- Wait up to 2 minutes (usually arrives in seconds)
- Check Resend dashboard to see if email was sent
- Verify email address is correct

### ❌ "User already exists"
- The email is already registered in database
- Try signing in instead
- Or delete the user from Supabase and try again

---

## Usage Limits (Free Tier)

- **Daily Limit**: 100 emails/day
- **Monthly Limit**: 3,000 emails/month
- **Rate Limit**: 1 request/second

This is MORE than enough for testing and small-scale use!

---

## Next Steps (Optional)

### Custom Domain (Recommended for Production)
1. In Resend dashboard, go to **Domains**
2. Add your domain (e.g., `studenthub.lebanon`)
3. Update DNS records as instructed
4. Change `fromEmail` in `EmailService.swift`:
   ```swift
   private let fromEmail = "Student Hub <noreply@studenthub.lebanon>"
   ```

### Increase Limits
If you need more emails:
- **Pro Plan**: $20/month for 50,000 emails
- **Pay As You Go**: $1 per 1,000 additional emails

---

## Security Notes

⚠️ **Current Implementation Uses Simple SHA256 Hashing**

For production, you should use **BCrypt**:
```swift
import BCrypt

private func hashPassword(_ password: String) -> String {
    return try! BCrypt.hash(password: password)
}

private func verifyPassword(_ password: String, matches hash: String) -> Bool {
    return try! BCrypt.verify(password: password, hash: hash)
}
```

Add via Swift Package Manager:
- Repository: `https://github.com/attaswift/BCrypt`
- Rule: `.upToNextMajor(from: "1.0.0")`

---

## Support

- Resend Docs: [https://resend.com/docs](https://resend.com/docs)
- Resend Discord: [https://discord.gg/resend](https://discord.gg/resend)

---

**🎉 You're all set! Say goodbye to Supabase email issues!**
