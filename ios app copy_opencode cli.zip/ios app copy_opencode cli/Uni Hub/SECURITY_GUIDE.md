# 🔒 Security Best Practices - API Key Management

## ✅ What We Did (Secure Implementation)

### **Problem with Hardcoded Keys:**
```swift
// ❌ BAD - Never do this!
private let resendAPIKey = "re_123456789"
```
- Anyone with access to your code can see the key
- Gets committed to Git history (even if deleted later)
- Violates security best practices
- Can lead to API abuse if code is leaked

### **Our Secure Solution:**
```swift
// ✅ GOOD - Using build configuration
private let resendAPIKey: String = {
    guard let apiKey = Bundle.main.object(forInfoDictionaryKey: "RESEND_API_KEY") as? String
    else {
        fatalError("API key not configured!")
    }
    return apiKey
}()
```

---

## 📁 Files Created for Security

### 1. **SecurityConfiguration.xcconfig**
Location: `Uni Hub/Uni Hub/SecurityConfiguration.xcconfig`

This file:
- Stores sensitive configuration outside of code
- Is NOT tracked by Git (should be in .gitignore)
- Can have different values for Debug/Release builds
- Is loaded at build time by Xcode

### 2. **Updated EmailService.swift**
Now reads API key securely from configuration instead of hardcoding it.

---

## 🔐 How It Works

```
┌─────────────────────────────────────────────────────────┐
│  SecurityConfiguration.xcconfig                         │
│  ┌───────────────────────────────────────────────┐     │
│  │ RESEND_API_KEY = re_actual_key_here          │     │
│  └───────────────────────────────────────────────┘     │
│                    ↓                                    │
│         (Read at build time)                            │
│                    ↓                                    │
│  ┌───────────────────────────────────────────────┐     │
│  │  Info.plist                                   │     │
│  │  <key>RESEND_API_KEY</key>                   │     │
│  │  <string>$(RESEND_API_KEY)</string>          │     │
│  └───────────────────────────────────────────────┘     │
│                    ↓                                    │
│         (Injected into app bundle)                      │
│                    ↓                                    │
│  ┌───────────────────────────────────────────────┐     │
│  │  EmailService.swift                           │     │
│  │  Bundle.main.object(...)                      │     │
│  │  → Gets key securely at runtime               │     │
│  └───────────────────────────────────────────────┘     │
└─────────────────────────────────────────────────────────┘
```

---

## ⚙️ Setup Instructions

### Step 1: Add Your API Key
Open `SecurityConfiguration.xcconfig` and replace:
```xcconfig
RESEND_API_KEY = re_YOUR_ACTUAL_API_KEY_HERE
```

With your actual Resend API key:
```xcconfig
RESEND_API_KEY = re_AbCdEfGhIjKlMnOpQrStUvWxYz123456
```

### Step 2: Configure Xcode Project

1. Open your Xcode project
2. Click on **"Uni Hub"** project file in Navigator
3. Select **"Uni Hub"** target
4. Go to **"Build Settings"** tab
5. Search for **"Configurations"**
6. Under **"Configurations"**, double-click on **"Debug"** → Choose **"SecurityConfiguration"**
7. Do the same for **"Release"**

### Step 3: Update Info.plist

1. In Xcode, open `Info.plist`
2. Add a new entry:
   - Key: `RESEND_API_KEY`
   - Type: `String`
   - Value: `$(RESEND_API_KEY)`

The `$(...)` syntax tells Xcode to substitute the value from the `.xcconfig` file.

---

## 🎯 Alternative: Environment Variables (Advanced)

For even better security (especially for CI/CD), use environment variables:

### Create `.env` file (not committed to Git):
```bash
# .env file
RESEND_API_KEY=re_your_key_here
```

### Use SwiftGen or similar tool to inject at build time

Or use a library like [SwiftDotEnv](https://github.com/SwiftDotEnv/SwiftDotEnv).

---

## 🛡️ Production Security Checklist

- ✅ **Never commit API keys** to version control
- ✅ **Use `.xcconfig` files** for configuration
- ✅ **Add `.xcconfig` to `.gitignore`**
- ✅ **Use different keys** for development and production
- ✅ **Rotate keys periodically**
- ✅ **Monitor API usage** for suspicious activity
- ✅ **Use App Attest** for additional iOS security (advanced)

---

## 📝 .gitignore Updates

Make sure your `.gitignore` includes:

```gitignore
# Xcode configuration files with secrets
*.xcconfig
!Template.xcconfig

# Environment files
.env
.env.*

# Build configurations
LocalConfiguration.xcconfig
Development.xcconfig
Production.xcconfig
```

---

## 🔄 For Team Collaboration

When working with a team:

1. **Create a template file**: `SecurityConfiguration.xcconfig.template`
2. **Commit the template** (without real keys)
3. **Share actual keys** via secure channels only:
   - 1Password
   - LastPass
   - Encrypted email
   - In-person

Example template:
```xcconfig
// SecurityConfiguration.xcconfig.template
// Copy this to SecurityConfiguration.xcconfig and fill in your values

RESEND_API_KEY = YOUR_API_KEY_HERE
```

---

## 🚨 If You Accidentally Committed a Key

1. **Rotate it immediately!**
   - Go to Resend dashboard
   - Delete the compromised key
   - Generate a new one
   
2. **Clean Git history** (if needed):
   ```bash
   # Use BFG Repo-Cleaner or git filter-branch
   bfg --delete-files SecurityConfiguration.xcconfig
   ```

3. **Force push** (be careful!):
   ```bash
   git push --force
   ```

4. **Notify team members** that the key was compromised

---

## 💡 Additional Security Tips

### 1. **Rate Limiting**
Implement rate limiting in your app to prevent abuse:
```swift
class RateLimiter {
    private var requests: [Date] = []
    
    func canMakeRequest() -> Bool {
        let oneMinuteAgo = Date().addingTimeInterval(-60)
        requests = requests.filter { $0 > oneMinuteAgo }
        
        guard requests.count < 5 else { // Max 5 requests per minute
            return false
        }
        
        requests.append(Date())
        return true
    }
}
```

### 2. **Input Validation**
Always validate email addresses before sending:
```swift
func isValidEmail(_ email: String) -> Bool {
    let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
    return NSPredicate(format: "SELF MATCHES %@", emailRegex).evaluate(with: email)
}
```

### 3. **Error Handling**
Don't expose sensitive information in errors:
```swift
// ❌ Bad - Exposes internal details
throw NSError(domain: "APIError", message: "Failed with key: \(apiKey)")

// ✅ Good - Generic error
throw NSError(domain: "APIError", message: "Failed to send email. Please try again.")
```

---

## 📚 Resources

- [Apple Security Overview](https://developer.apple.com/security/)
- [OWASP Mobile Security Guidelines](https://owasp.org/www-project-mobile-security/)
- [Resend Security Best Practices](https://resend.com/docs/security)

---

**🎉 You're now following industry-standard security practices!**

Your API keys are safe from accidental commits and code exposure. This is how professional iOS apps handle sensitive configuration.
