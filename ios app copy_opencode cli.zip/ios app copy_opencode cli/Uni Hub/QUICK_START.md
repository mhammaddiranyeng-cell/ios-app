# 🔑 Quick Start - Add Your Resend API Key (Secure Method)

## 3 Simple Steps to Get Started

### Step 1️⃣: Get Your Free API Key (2 minutes)

1. Go to **https://resend.com**
2. Click **"Sign Up"**
3. Verify your email
4. Go to **API Keys** → Copy your key (starts with `re_`)

---

### Step 2️⃣: Add Key to Config File (30 seconds)

1. Open in Xcode: `Uni Hub/Uni Hub/SecurityConfiguration.xcconfig`
2. Replace the placeholder on line 9:

```xcconfig
// BEFORE:
RESEND_API_KEY = re_YOUR_ACTUAL_API_KEY_HERE

// AFTER (use YOUR actual key):
RESEND_API_KEY = re_AbCdEfGhIjKlMnOpQrStUvWxYz123456
```

✅ **Done!** Your key is now secure and won't be committed to Git.

---

### Step 3️⃣: Configure Xcode (1 minute)

1. In Xcode, click **"Uni Hub"** project (blue icon in Navigator)
2. Select **"Uni Hub"** target
3. Click **"Build Settings"** tab
4. Search for: `Configurations`
5. Double-click **"Debug"** → Choose **"SecurityConfiguration"**
6. Do the same for **"Release"**

---

### Bonus: Update Info.plist (if emails don't work)

1. Open `Info.plist` in Xcode
2. Right-click → **Add Row**
3. Key: `RESEND_API_KEY`
4. Value: `$(RESEND_API_KEY)`

---

## ✅ Test It!

1. Run the app (Cmd + R)
2. Sign up with your email
3. You'll get the OTP email in seconds! 📧

---

## 🎯 What If I See This Error?

```
⚠️ RESEND_API_KEY not configured in SecurityConfiguration.xcconfig!
```

**Fix:** You either:
- Didn't add your API key to `SecurityConfiguration.xcconfig`
- Or forgot to configure Xcode Build Settings (Step 3)

Go back through the steps above! ✅

---

## 📁 File Locations

| File | Purpose | Location |
|------|---------|----------|
| `SecurityConfiguration.xcconfig` | Store API key securely | `Uni Hub/Uni Hub/` |
| `EmailService.swift` | Sends emails via Resend | `Uni Hub/Services/Email/` |
| `Info.plist` | App configuration | `Uni Hub/Uni Hub/` |

---

## 🔒 Why This Method?

| Method | Secure? | Git-Safe? | Recommended? |
|--------|---------|-----------|--------------|
| **`.xcconfig`** | ✅ Yes | ✅ Yes | ✅ **USE THIS** |
| Hardcoded in code | ❌ No | ❌ No | ❌ Never use |
| Environment variable | ⚠️ Maybe | ✅ Yes | ⚠️ Complex setup |

---

**🎉 That's it! You're all set up securely!**

For more details, see:
- `SETUP_RESEND.md` - Complete setup guide
- `SECURITY_GUIDE.md` - Security best practices
