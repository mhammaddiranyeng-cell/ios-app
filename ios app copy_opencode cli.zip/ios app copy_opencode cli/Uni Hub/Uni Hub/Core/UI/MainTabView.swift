import SwiftUI

struct MainTabView: View {
    @EnvironmentObject var appState: AppState
    @EnvironmentObject var authManager: AuthManager
    
    var body: some View {
        NavigationView {
            TabView {
                HomeView()
                    .tabItem {
                        Label("Home", systemImage: "house.fill")
                    }
                
                MarketplaceView()
                    .tabItem {
                        Label("Market", systemImage: "bag.fill")
                    }
                
                PlannerView()
                    .tabItem {
                        Label("Planner", systemImage: "calendar")
                    }
                
                CommunityView()
                    .tabItem {
                        Label("Community", systemImage: "person.3.fill")
                    }
                
                ProfileView()
                    .tabItem {
                        Label("Profile", systemImage: "person.crop.circle")
                    }
            }
            .navigationBarHidden(true) // Hide the top bar on the root TabView itself
        }
    }
}
