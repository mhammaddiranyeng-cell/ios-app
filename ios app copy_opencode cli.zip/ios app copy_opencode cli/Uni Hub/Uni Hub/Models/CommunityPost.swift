import Foundation
import SwiftUI

// MARK: - Material Type

enum MaterialType: String, Codable, CaseIterable, Identifiable {
    case exam       = "Exam"
    case quiz       = "Quiz"
    case homework   = "Homework"
    case notes      = "Notes"
    case other      = "Other"

    var id: String { rawValue }

    var icon: String {
        switch self {
        case .exam:     return "doc.text.magnifyingglass"
        case .quiz:     return "checkmark.rectangle"
        case .homework: return "pencil.and.list.clipboard"
        case .notes:    return "note.text"
        case .other:    return "paperclip"
        }
    }

    var color: Color {
        switch self {
        case .exam:     return .red
        case .quiz:     return .orange
        case .homework: return .purple
        case .notes:    return .blue
        case .other:    return .gray
        }
    }
}

// MARK: - Community Post

struct CommunityPost: Identifiable {
    let id: UUID
    let uploaderName: String
    let universityName: String      // Full name from dataset
    let facultyName: String
    let majorName: String
    let courseCode: String          // e.g. "EECE 330" (optional, may be empty)
    let courseName: String          // e.g. "Control Systems" (optional, may be empty)
    let materialType: MaterialType
    let title: String
    let description: String
    let uploadedAt: Date

    /// Human-readable course identifier shown in cards
    var courseLabel: String {
        if !courseCode.isEmpty && !courseName.isEmpty {
            return "\(courseCode) – \(courseName)"
        } else if !courseCode.isEmpty {
            return courseCode
        } else if !courseName.isEmpty {
            return courseName
        }
        return "General"
    }

    /// Searchable text combining all relevant fields
    var searchTokens: String {
        [title, courseCode, courseName, materialType.rawValue,
         uploaderName, facultyName, majorName, universityName]
            .joined(separator: " ").lowercased()
    }
}
