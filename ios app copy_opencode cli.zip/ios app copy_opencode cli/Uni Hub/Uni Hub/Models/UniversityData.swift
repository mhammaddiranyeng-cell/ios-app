import Foundation

// MARK: - University Hierarchy Models (sourced from lebanon_undergrad_programs.csv)

struct LBUniversity: Identifiable, Codable, Hashable {
    let id: UUID
    let name: String
    let faculties: [LBFaculty]

    /// Short code extracted from parentheses, e.g. "AUST" from "American University of Science and Technology (AUST)"
    var shortCode: String {
        if let open = name.lastIndex(of: "("), let close = name.lastIndex(of: ")") {
            let start = name.index(after: open)
            return String(name[start..<close])
        }
        return name
    }

    /// Display name without the parenthetical abbreviation
    var displayName: String {
        if let idx = name.lastIndex(of: "(") {
            return String(name[..<idx]).trimmingCharacters(in: .whitespaces)
        }
        return name
    }

    enum CodingKeys: String, CodingKey { case name, faculties }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        self.id = UUID()
        self.name = try c.decode(String.self, forKey: .name)
        self.faculties = try c.decode([LBFaculty].self, forKey: .faculties)
    }
    func encode(to encoder: Encoder) throws {
        var c = encoder.container(keyedBy: CodingKeys.self)
        try c.encode(name, forKey: .name)
        try c.encode(faculties, forKey: .faculties)
    }
}

struct LBFaculty: Identifiable, Codable, Hashable {
    let id: UUID
    let name: String
    let majors: [LBMajor]

    enum CodingKeys: String, CodingKey { case name, majors }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        self.id = UUID()
        self.name = try c.decode(String.self, forKey: .name)
        self.majors = try c.decode([LBMajor].self, forKey: .majors)
    }
    func encode(to encoder: Encoder) throws {
        var c = encoder.container(keyedBy: CodingKeys.self)
        try c.encode(name, forKey: .name)
        try c.encode(majors, forKey: .majors)
    }
}

struct LBMajor: Identifiable, Codable, Hashable {
    let id: UUID
    let name: String
    let degree: String

    enum CodingKeys: String, CodingKey { case name, degree }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        self.id = UUID()
        self.name = try c.decode(String.self, forKey: .name)
        self.degree = try c.decode(String.self, forKey: .degree)
    }
    func encode(to encoder: Encoder) throws {
        var c = encoder.container(keyedBy: CodingKeys.self)
        try c.encode(name, forKey: .name)
        try c.encode(degree, forKey: .degree)
    }
}

// Top-level JSON wrapper
private struct UniversitiesRoot: Codable {
    let universities: [LBUniversity]
}

// MARK: - Data Store
class UniversityDataStore {
    static let shared = UniversityDataStore()
    private(set) var universities: [LBUniversity] = []

    private init() {
        guard let url = Bundle.main.url(forResource: "universities", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let root = try? JSONDecoder().decode(UniversitiesRoot.self, from: data)
        else {
            print("⚠️ UniversityDataStore: Failed to load universities.json")
            return
        }
        self.universities = root.universities
    }

    func faculties(for university: LBUniversity) -> [LBFaculty] {
        university.faculties
    }

    func majors(for faculty: LBFaculty) -> [LBMajor] {
        faculty.majors
    }

    func university(named name: String) -> LBUniversity? {
        universities.first { $0.name.contains(name) || $0.shortCode == name }
    }
}
