import Foundation
import Combine
import CommonCrypto

class AuthManager: ObservableObject {
    @Published var isAuthenticated: Bool = false
    @Published var currentUser: User?
    
    private let otpManager = OTPManager()
    private let databaseClient = SupabaseRESTClient(
        url: URL(string: "https://dzgthecgkzsgiontbaad.supabase.co")!,
        key: "sb_publishable_5R_1g_2nFXa43Ziy2CcWIg_2sKNA6gf"
    )
    
    init() {
        checkSession()
    }
    
    func checkSession() {
        if let _ = UserDefaults.standard.string(forKey: "auth_token"),
           let userId = UserDefaults.standard.string(forKey: "user_id") {
            self.isAuthenticated = true
            self.currentUser = User(id: UUID(uuidString: userId) ?? UUID(), email: UserDefaults.standard.string(forKey: "user_email") ?? "", fullName: "User", role: .student, isPro: false)
        }
    }
    
    func signUp(email: String, password: String) async throws {
        // Create user in database
        let userRecord: [String: AnyHashable] = [
            "email": email,
            "password_hash": hashPassword(password),
            "created_at": ISO8601DateFormatter().string(from: Date()),
            "is_verified": false
        ]
        
        // Insert into users table
        let _: EmptyResponse = try await databaseClient.request(
            table: "users",
            method: "POST",
            body: userRecord
        )
        
        // Generate and send OTP via Resend
        try await otpManager.generateAndSendOTP(email: email, isSignUp: true)
        print("✅ Sign up successful. OTP sent to \(email)")
    }
    
    func signIn(email: String, password: String) async throws {
        // Fetch user from database
        let response = try await databaseClient.requestRaw(
            table: "users",
            method: "GET",
            query: ["email": "eq.\(email)"]
        )
        
        guard let jsonArray = response as? [[String: Any]],
              let userRecord = jsonArray.first else {
            throw NSError(domain: "AuthError", code: 404, userInfo: [NSLocalizedDescriptionKey: "User not found"])
        }
        
        guard let storedHash = userRecord["password_hash"] as? String else {
            throw NSError(domain: "AuthError", code: 401, userInfo: [NSLocalizedDescriptionKey: "Invalid credentials"])
        }
        
        // Verify password
        if !verifyPassword(password, matches: storedHash) {
            throw NSError(domain: "AuthError", code: 401, userInfo: [NSLocalizedDescriptionKey: "Invalid credentials"])
        }
        
        // Check if verified
        let isVerified = userRecord["is_verified"] as? Bool ?? false
        if !isVerified {
            // Send OTP for unverified user
            try await otpManager.generateAndSendOTP(email: email, isSignUp: false)
            throw NSError(domain: "AuthError", code: 403, userInfo: [NSLocalizedDescriptionKey: "Email not verified. OTP sent."])
        }
        
        // Login successful
        let userId = userRecord["id"] as? String ?? UUID().uuidString
        UserDefaults.standard.set(userId, forKey: "user_id")
        UserDefaults.standard.set(email, forKey: "user_email")
        UserDefaults.standard.set(true, forKey: "auth_token")
        
        DispatchQueue.main.async {
            self.isAuthenticated = true
            self.currentUser = User(
                id: UUID(uuidString: userId) ?? UUID(),
                email: email,
                fullName: userRecord["full_name"] as? String ?? "User",
                role: .student,
                isPro: false
            )
        }
    }
    
    func requestOTP(email: String) async throws {
        try await otpManager.generateAndSendOTP(email: email, isSignUp: false)
    }
    
    func verifyOTP(email: String, token: String) async throws {
        let isValid = otpManager.verifyOTP(email: email, token: token)
        
        guard isValid else {
            throw NSError(domain: "AuthError", code: 401, userInfo: [NSLocalizedDescriptionKey: "Invalid or expired OTP"])
        }
        
        // Mark user as verified in database
        let updateData: [String: AnyHashable] = ["is_verified": true]
        let _: EmptyResponse = try await databaseClient.request(
            table: "users",
            method: "PATCH",
            body: updateData,
            query: ["email": "eq.\(email)"]
        )
        
        // Auto-login after verification
        let response = try await databaseClient.requestRaw(
            table: "users",
            method: "GET",
            query: ["email": "eq.\(email)"]
        )
        
        if let jsonArray = response as? [[String: Any]],
           let userRecord = jsonArray.first {
            let userId = userRecord["id"] as? String ?? UUID().uuidString
            UserDefaults.standard.set(userId, forKey: "user_id")
            UserDefaults.standard.set(email, forKey: "user_email")
            UserDefaults.standard.set(true, forKey: "auth_token")
            
            DispatchQueue.main.async {
                self.isAuthenticated = true
                self.currentUser = User(
                    id: UUID(uuidString: userId) ?? UUID(),
                    email: email,
                    fullName: userRecord["full_name"] as? String ?? "User",
                    role: .student,
                    isPro: false
                )
            }
        }
    }
    
    func signInWithApple() {
        // Implementation for native Sign in with Apple
    }
    
    func signOut() {
        UserDefaults.standard.removeObject(forKey: "auth_token")
        UserDefaults.standard.removeObject(forKey: "user_id")
        UserDefaults.standard.removeObject(forKey: "user_email")
        
        DispatchQueue.main.async {
            self.isAuthenticated = false
            self.currentUser = nil
        }
    }
    
    // MARK: - Password Hashing (Simple SHA256)
    // TODO: Replace with BCrypt for production!
    private func hashPassword(_ password: String) -> String {
        guard let data = password.data(using: .utf8) else { return "" }
        let hash = data.sha256()
        return hash
    }
    
    private func verifyPassword(_ password: String, matches hash: String) -> Bool {
        return hashPassword(password) == hash
    }
}

// MARK: - SHA256 Extension
extension Data {
    func sha256() -> String {
        var hash = [UInt8](repeating: 0, count: Int(CC_SHA256_DIGEST_LENGTH))
        withUnsafeBytes {
            _ = CC_SHA256($0.baseAddress, CC_LONG(count), &hash)
        }
        return hash.map { String(format: "%02x", $0) }.joined()
    }
}
