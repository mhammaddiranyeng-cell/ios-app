import Foundation

class OTPManager: ObservableObject {
    @Published var otpRequests: [String: OTPRequest] = [:] // email -> OTPRequest
    
    struct OTPRequest {
        let otp: String
        let expiresAt: Date
        let isSignUp: Bool
    }
    
    private let otpExpirationTime: TimeInterval = 10 * 60 // 10 minutes
    
    // Generate and send OTP
    func generateAndSendOTP(email: String, isSignUp: Bool) async throws {
        let otp = EmailService.shared.generateOTP()
        let expirationDate = Date().addingTimeInterval(otpExpirationTime)
        
        // Store OTP temporarily
        otpRequests[email] = OTPRequest(otp: otp, expiresAt: expirationDate, isSignUp: isSignUp)
        
        // Send email via Resend
        try await EmailService.shared.sendOTP(email: email, otp: otp, isSignUp: isSignUp)
        
        print("📧 OTP sent to \(email): \(otp) (expires at \(expirationDate))")
    }
    
    // Verify OTP
    func verifyOTP(email: String, token: String) -> Bool {
        guard let request = otpRequests[email] else {
            print("❌ No OTP found for email: \(email)")
            return false
        }
        
        if Date() > request.expiresAt {
            print("❌ OTP expired for email: \(email)")
            otpRequests.removeValue(forKey: email)
            return false
        }
        
        if request.otp != token {
            print("❌ Invalid OTP for email: \(email)")
            return false
        }
        
        print("✅ OTP verified successfully for email: \(email)")
        otpRequests.removeValue(forKey: email) // Remove after successful verification
        return true
    }
    
    // Clear all OTPs (for testing)
    func clearAllOTPs() {
        otpRequests.removeAll()
    }
}
