import SwiftUI

enum MarketCategory: String, CaseIterable, Identifiable {
    case textbooks = "Textbooks"
    case services = "Services"
    case electronics = "Electronics"
    case transport = "Transport"
    case other = "Other"
    
    var id: String { self.rawValue }
    
    var icon: String {
        switch self {
        case .textbooks: return "book.closed.fill"
        case .services: return "person.2.fill"
        case .electronics: return "laptopcomputer"
        case .transport: return "car.fill"
        case .other: return "ellipsis.circle.fill"
        }
    }
}

struct MarketplaceListing: Identifiable {
    let id = UUID()
    let title: String
    let description: String
    let price: String
    let category: MarketCategory
    let uploaderName: String
    let university: String
    let major: String?
    let imageName: String?
    let date: Date
    let isPromoted: Bool
}

class MarketplaceStore: ObservableObject {
    static let shared = MarketplaceStore()
    
    @Published var listings: [MarketplaceListing] = []
    
    private init() {
        seedMockData()
    }
    
    func seedMockData() {
        listings = [
            MarketplaceListing(
                title: "Introduction to Algorithms (CLRS)",
                description: "Barely used, 3rd Edition. Essential for Computer Science majors. No highlights.",
                price: "$35",
                category: .textbooks,
                uploaderName: "Marc D.",
                university: "AUB",
                major: "Computer Science",
                imageName: nil,
                date: Date().addingTimeInterval(-86400 * 2),
                isPromoted: true
            ),
            MarketplaceListing(
                title: "Calculus: Early Transcendentals",
                description: "Used but in good condition. 8th Edition.",
                price: "$20",
                category: .textbooks,
                uploaderName: "Sara K.",
                university: "LAU",
                major: "Mechanical Engineering",
                imageName: nil,
                date: Date().addingTimeInterval(-86400 * 5),
                isPromoted: false
            ),
            MarketplaceListing(
                title: "Private Tutoring: Java & Python",
                description: "Helping students with intro to programming courses. $15/hour.",
                price: "$15/h",
                category: .services,
                uploaderName: "Ali H.",
                university: "LU",
                major: "CCE",
                imageName: nil,
                date: Date().addingTimeInterval(-3600 * 4),
                isPromoted: true
            ),
            MarketplaceListing(
                title: "Graphic Design Services",
                description: "Need help with your poster or presentation? Student discount rates.",
                price: "Varies",
                category: .services,
                uploaderName: "Mia T.",
                university: "ALBA",
                major: "Global Design",
                imageName: nil,
                date: Date().addingTimeInterval(-86400 * 1),
                isPromoted: false
            ),
            MarketplaceListing(
                title: "TI-84 Plus CE Graphing Calculator",
                description: "Perfect condition, charger included. Used for one semester.",
                price: "$70",
                category: .electronics,
                uploaderName: "James W.",
                university: "AUST",
                major: "Business",
                imageName: nil,
                date: Date().addingTimeInterval(-86400 * 3),
                isPromoted: false
            ),
            MarketplaceListing(
                title: "Carpool from Jbeil to Beirut",
                description: "Daily commute at 7:30 AM. 3 seats available.",
                price: "$2",
                category: .transport,
                uploaderName: "Rami S.",
                university: "LAU",
                major: nil,
                imageName: nil,
                date: Date().addingTimeInterval(-3600 * 2),
                isPromoted: false
            )
        ]
    }
    
    func listings(for category: MarketCategory?) -> [MarketplaceListing] {
        guard let category = category else { return listings }
        return listings.filter { $0.category == category }
    }
}
