import Foundation

class SupabaseRESTClient {
    private let url: URL
    private let key: String
    
    init(url: URL, key: String) {
        self.url = url
        self.key = key
    }
    
    // Generic request for Database (PostgREST)
    func request<T: Decodable>(table: String, method: String = "GET", body: [String: AnyHashable]? = nil, query: [String: String]? = nil) async throws -> T {
        var urlComponents = URLComponents(url: url.appendingPathComponent("rest/v1/\(table)"), resolvingAgainstBaseURL: false)!
        
        if let query = query {
            urlComponents.queryItems = query.map { URLQueryItem(name: $0.key, value: $0.value) }
        }
        
        var request = URLRequest(url: urlComponents.url!)
        request.httpMethod = method
        request.addValue(key, forHTTPHeaderField: "apikey")
        request.addValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Prefer")
        
        if let body = body {
            request.httpBody = try JSONSerialization.data(withJSONObject: body)
        }
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
            throw NSError(domain: "SupabaseErrors", code: (response as? HTTPURLResponse)?.statusCode ?? -1, userInfo: [NSLocalizedDescriptionKey: String(data: data, encoding: .utf8) ?? "Unknown Error"])
        }
        
        let decoder = JSONDecoder()
        // Handle Supabase date formats if needed
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZZZZZ"
        decoder.dateDecodingStrategy = .formatted(formatter)
        
        return try decoder.decode(T.self, from: data)
    }
    
    // Raw request that returns Any (for dynamic responses)
    func requestRaw(table: String, method: String = "GET", body: [String: AnyHashable]? = nil, query: [String: String]? = nil) async throws -> Any {
        var urlComponents = URLComponents(url: url.appendingPathComponent("rest/v1/\(table)"), resolvingAgainstBaseURL: false)!
        
        if let query = query {
            urlComponents.queryItems = query.map { URLQueryItem(name: $0.key, value: $0.value) }
        }
        
        var request = URLRequest(url: urlComponents.url!)
        request.httpMethod = method
        request.addValue(key, forHTTPHeaderField: "apikey")
        request.addValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        if let body = body {
            request.httpBody = try JSONSerialization.data(withJSONObject: body)
        }
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
            throw NSError(domain: "SupabaseErrors", code: (response as? HTTPURLResponse)?.statusCode ?? -1, userInfo: [NSLocalizedDescriptionKey: String(data: data, encoding: .utf8) ?? "Unknown Error"])
        }
        
        // Parse as JSON (Any)
        let json = try JSONSerialization.jsonObject(with: data, options: [])
        return json
    }
    
    // Auth (GoTrue) implementation placeholders for session management
    func authRequest<T: Decodable>(endpoint: String, method: String = "POST", body: [String: Any]? = nil) async throws -> T {
        let url = self.url.appendingPathComponent("auth/v1/\(endpoint)")
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.addValue(key, forHTTPHeaderField: "apikey")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        if let body = body {
            request.httpBody = try JSONSerialization.data(withJSONObject: body)
        }
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
            let errorMsg = String(data: data, encoding: .utf8) ?? "Unknown Auth Error"
            throw NSError(domain: "AuthError", code: (response as? HTTPURLResponse)?.statusCode ?? -1, userInfo: [NSLocalizedDescriptionKey: errorMsg])
        }
        
        return try JSONDecoder().decode(T.self, from: data)
    }
}

// MARK: - Auth Models
struct EmptyResponse: Decodable {}

struct AuthResponse: Decodable {
    let accessToken: String?
    let tokenType: String?
    let expiresIn: Int?
    let refreshToken: String?
    let user: AuthUser?
    
    enum CodingKeys: String, CodingKey {
        case accessToken = "access_token"
        case tokenType = "token_type"
        case expiresIn = "expires_in"
        case refreshToken = "refresh_token"
        case user
    }
}

struct AuthUser: Decodable {
    let id: String
    let email: String?
}
