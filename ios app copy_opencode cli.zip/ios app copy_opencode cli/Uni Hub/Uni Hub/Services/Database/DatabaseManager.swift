import Foundation

class DatabaseManager {
    static let shared = DatabaseManager()
    
    private let client = SupabaseRESTClient(
        url: URL(string: "https://dzgthecgkzsgiontbaad.supabase.co")!,
        key: "sb_publishable_5R_1g_2nFXa43Ziy2CcWIg_2sKNA6gf"
    )
    
    func fetchCourses() async throws -> [Course] {
        return try await client.request(table: "courses")
    }
    
    func fetchResources(for courseId: UUID) async throws -> [Resource] {
        return try await client.request(table: "course_resources", query: ["course_id": "eq.\(courseId.uuidString)"])
    }
    
    func uploadResource(data: Data, fileName: String, courseId: UUID, title: String) async throws {
        // Note: Manual upload to Storage requires a bit more boilerplate with URLSession
        // This is a placeholder for the REST API approach for storage
    }
}
