import Foundation
import Combine

class CommunityStore: ObservableObject {
    static let shared = CommunityStore()

    @Published private(set) var posts: [CommunityPost] = []

    private init() {
        seedSampleData()
    }

    // MARK: - Public API

    func add(post: CommunityPost) {
        posts.insert(post, at: 0)
    }

    func search(query: String, in posts: [CommunityPost]) -> [CommunityPost] {
        let q = query.lowercased().trimmingCharacters(in: .whitespaces)
        guard !q.isEmpty else { return posts }
        return posts.filter { $0.searchTokens.contains(q) }
    }

    func posts(for university: String, faculty: String? = nil, major: String? = nil) -> [CommunityPost] {
        posts.filter { post in
            guard post.universityName == university else { return false }
            if let f = faculty, post.facultyName != f { return false }
            if let m = major, post.majorName != m { return false }
            return true
        }
    }

    // MARK: - Seed realistic sample data

    private func seedSampleData() {
        let now = Date()
        let samples: [CommunityPost] = [
            CommunityPost(id: UUID(), uploaderName: "Lara T.", universityName: "American University of Beirut (AUB)",
                          facultyName: "Maroun Semaan Faculty of Engineering and Architecture",
                          majorName: "Computer and Communications Engineering",
                          courseCode: "EECE 330", courseName: "Control Systems",
                          materialType: .exam, title: "Midterm 2024 – Control Systems",
                          description: "Full midterm with solutions, covers PID and root locus.",
                          uploadedAt: now.addingTimeInterval(-3600 * 24 * 2)),

            CommunityPost(id: UUID(), uploaderName: "Omar S.", universityName: "Lebanese American University (LAU)",
                          facultyName: "School of Engineering",
                          majorName: "Computer Engineering",
                          courseCode: "CSC 447", courseName: "Operating Systems",
                          materialType: .notes, title: "Chapter 4 Notes – Scheduling",
                          description: "Summarized notes with diagrams for OS scheduling algorithms.",
                          uploadedAt: now.addingTimeInterval(-3600 * 48)),

            CommunityPost(id: UUID(), uploaderName: "Maya B.", universityName: "American University of Science and Technology (AUST)",
                          facultyName: "Faculty of Business and Economics",
                          majorName: "Marketing",
                          courseCode: "MKT 201", courseName: "Marketing Principles",
                          materialType: .quiz, title: "Quiz 3 – Consumer Behaviour",
                          description: "Quiz 3 with answer key.",
                          uploadedAt: now.addingTimeInterval(-3600 * 72)),

            CommunityPost(id: UUID(), uploaderName: "Jad K.", universityName: "Notre Dame University – Louaize (NDU)",
                          facultyName: "Faculty of Engineering",
                          majorName: "Civil Engineering",
                          courseCode: "CVL 305", courseName: "Structural Analysis",
                          materialType: .homework, title: "HW 5 – Frame Analysis",
                          description: "Homework set 5 with full worked solutions.",
                          uploadedAt: now.addingTimeInterval(-3600 * 10)),

            CommunityPost(id: UUID(), uploaderName: "Sara M.", universityName: "Lebanese American University (LAU)",
                          facultyName: "School of Arts and Sciences",
                          majorName: "Computer Science",
                          courseCode: "CSC 320", courseName: "Algorithms",
                          materialType: .exam, title: "Final Exam 2023",
                          description: "Final exam — graph algorithms section included.",
                          uploadedAt: now.addingTimeInterval(-3600 * 24 * 5))
        ]
        self.posts = samples
    }
}
