import Foundation

class EmailService {
    static let shared = EmailService()
    
    // API key from environment variable or hardcoded fallback
    // For Xcode 14.2 compatibility - reads from .xcconfig at compile time
    private var resendAPIKey: String {
        // Option 1: Try to read from compiled configuration
        if let apiKey = ProcessInfo.processInfo.environment["RESEND_API_KEY"],
           !apiKey.isEmpty,
           apiKey != "re_YOUR_ACTUAL_API_KEY_HERE" {
            return apiKey
        }
        
        // Option 2: Fallback - define directly here for testing
        // Replace this with your actual key OR use the xcconfig method above
        let hardcodedKey = "re_Eoeuzixo_4P737h4dR5DLVRZB1WZgs8GW"
        
        if hardcodedKey != "re_YOUR_ACTUAL_API_KEY_HERE" && !hardcodedKey.isEmpty {
            return hardcodedKey
        }
        
        fatalError("\n\n⚠️  RESEND_API_KEY not configured!\n\nYour key in SecurityConfiguration.xcconfig: \(hardcodedKey)\n\nMake sure it's a valid Resend API key (starts with 're_')\nGet your free API key at: https://resend.com\n")
    }
    
    private let fromEmail = "Student Hub <onboarding@resend.dev>"
    
    // Generate a random 6-digit OTP
    func generateOTP() -> String {
        return String(format: "%06d", Int.random(in: 0...999999))
    }
    
    // Send OTP via Resend API
    func sendOTP(email: String, otp: String, isSignUp: Bool) async throws {
        let subject = isSignUp ? "Verify Your Email - Student Hub Lebanon" : "Your Login Code - Student Hub Lebanon"
        let htmlContent = """
        <!DOCTYPE html>
        <html>
          <head>
            <style>
              body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }
              .container { max-width: 600px; margin: 0 auto; padding: 20px; }
              .header { background: linear-gradient(135deg, #007AFF 0%, #5856D6 100%); color: white; padding: 30px; border-radius: 12px 12px 0 0; text-align: center; }
              .content { background: #f5f5f7; padding: 40px; border-radius: 0 0 12px 12px; }
              .otp-code { background: white; padding: 20px; border-radius: 8px; font-size: 32px; font-weight: bold; letter-spacing: 8px; text-align: center; margin: 20px 0; color: #007AFF; }
              .footer { text-align: center; color: #86868b; font-size: 12px; margin-top: 20px; }
            </style>
          </head>
          <body>
            <div class="container">
              <div class="header">
                <h1>\(isSignUp ? "Welcome to Student Hub!" : "Welcome Back!")</h1>
              </div>
              <div class="content">
                <p>Hello,</p>
                <p>\(isSignUp ? "Thanks for signing up!" : "You're trying to sign in.")</p>
                <p>Your verification code is:</p>
                <div class="otp-code">\(otp)</div>
                <p>This code will expire in 10 minutes.</p>
                <p>If you didn't request this code, please ignore this email.</p>
                <div class="footer">
                  <p>Student Hub Lebanon - Connecting Students Everywhere</p>
                </div>
              </div>
            </div>
          </body>
        </html>
        """
        
        let url = URL(string: "https://api.resend.com/emails")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("Bearer \(resendAPIKey)", forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let body: [String: Any] = [
            "from": fromEmail,
            "to": [email],
            "subject": subject,
            "html": htmlContent
        ]
        
        request.httpBody = try JSONSerialization.data(withJSONObject: body)
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
            let errorBody = String(data: data, encoding: .utf8) ?? "Unknown error"
            throw NSError(domain: "EmailError", code: -1, userInfo: [NSLocalizedDescriptionKey: "Failed to send email: \(errorBody)"])
        }
        
        print("✅ Email sent successfully to \(email)")
    }
}
