import SwiftUI

struct PlannerView: View {
    @State private var selectedDate = Date()
    @State private var showingAddSheet = false
    
    var body: some View {
        VStack {
            // Simplistic Calendar Strip
            DatePicker("Select Date", selection: $selectedDate, displayedComponents: .date)
                .datePickerStyle(.graphical)
                .padding()
            
            Divider()
            
            List {
                Section(header: Text("Tasks for Today")) {
                    TaskRow(title: "Submit Web Dev Assignment", course: "CMPS 278", time: "11:59 PM", type: .assignment)
                    TaskRow(title: "Study for AI Midterm", course: "CMPS 280", time: "All Day", type: .reminder)
                }
            }
            .listStyle(.plain)
        }
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button(action: { showingAddSheet = true }) {
                    Image(systemName: "plus")
                }
            }
        }
        .sheet(isPresented: $showingAddSheet) {
            AddPlannerItemView()
        }
    }
}

enum PlannerItemType {
    case assignment, exam, reminder
}

struct TaskRow: View {
    let title: String
    let course: String
    let time: String
    let type: PlannerItemType
    @State private var isDone = false
    
    var body: some View {
        HStack {
            Button(action: { isDone.toggle() }) {
                Image(systemName: isDone ? "checkmark.circle.fill" : "circle")
                    .foregroundColor(isDone ? .green : .gray)
            }
            .buttonStyle(.plain)
            
            VStack(alignment: .leading) {
                Text(title)
                    .strikethrough(isDone, color: .gray)
                HStack {
                    Text(course)
                    Text("•")
                    Text(time)
                }
                .font(.caption)
                .foregroundColor(.secondary)
            }
        }
    }
}

struct AddPlannerItemView: View {
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Details")) {
                    TextField("Title", text: .constant(""))
                    Picker("Course", selection: .constant("None")) {
                        Text("None").tag("None")
                        Text("CSCI 200").tag("CSCI 200")
                    }
                    DatePicker("Due Date", selection: .constant(Date()))
                }
            }
            .navigationTitle("New Planner Item")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Add") { dismiss() }
                }
            }
        }
    }
}
