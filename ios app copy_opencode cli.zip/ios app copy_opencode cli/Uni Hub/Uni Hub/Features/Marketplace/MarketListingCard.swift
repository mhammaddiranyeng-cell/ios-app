import SwiftUI

struct MarketListingCard: View {
    let listing: MarketplaceListing
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            // Image Placeholder / Promotional Badge
            ZESack {
                if let _ = listing.imageName {
                    // Image placeholder
                    Color.gray.opacity(0.1)
                } else {
                    LinearGradient(
                        gradient: Gradient(colors: [listing.category.color.opacity(0.3), listing.category.color.opacity(0.1)]),
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                }
                
                VStack {
                    HStack {
                        if listing.isPromoted {
                            Text("PROMOTED")
                                .font(.system(size: 8, weight: .black))
                                .padding(.horizontal, 6)
                                .padding(.vertical, 3)
                                .background(Color.orange)
                                .foregroundColor(.white)
                                .cornerRadius(4)
                                .padding(8)
                        }
                        Spacer()
                        
                        Image(systemName: listing.category.icon)
                            .font(.system(size: 20))
                            .foregroundColor(listing.category.color)
                            .padding(10)
                            .background(.ultraThinMaterial)
                            .clipShape(Circle())
                            .padding(8)
                    }
                    Spacer()
                }
            }
            .frame(height: 120)
            .clipped()
            
            // Content
            VStack(alignment: .leading, spacing: 8) {
                HStack(alignment: .top) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(listing.title)
                            .font(.system(size: 16, weight: .bold))
                            .lineLimit(2)
                            .foregroundColor(.primary)
                        
                        HStack(spacing: 4) {
                            Text(listing.university)
                                .font(.system(size: 10, weight: .semibold))
                                .padding(.horizontal, 6)
                                .padding(.vertical, 2)
                                .background(Color.blue.opacity(0.1))
                                .foregroundColor(.blue)
                                .cornerRadius(4)
                            
                            if let major = listing.major {
                                Text(major)
                                    .font(.system(size: 10))
                                    .foregroundColor(.secondary)
                                    .lineLimit(1)
                            }
                        }
                    }
                    
                    Spacer()
                    
                    Text(listing.price)
                        .font(.system(size: 18, weight: .black))
                        .foregroundColor(.primary)
                }
                
                Text(listing.description)
                    .font(.system(size: 12))
                    .foregroundColor(.secondary)
                    .lineLimit(2)
                    .padding(.top, 2)
                
                HStack {
                    Image(systemName: "person.circle")
                        .font(.system(size: 12))
                        .foregroundColor(.secondary)
                    Text(listing.uploaderName)
                        .font(.system(size: 12))
                        .foregroundColor(.secondary)
                    
                    Spacer()
                    
                    Text(timeAgo(listing.date))
                        .font(.system(size: 10))
                        .foregroundColor(.secondary)
                }
                .padding(.top, 4)
            }
            .padding(12)
        }
        .background(Color(.secondarySystemBackground))
        .cornerRadius(16)
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(Color.primary.opacity(0.05), lineWidth: 1)
        )
        .shadow(color: Color.black.opacity(0.05), radius: 10, x: 0, y: 5)
    }
    
    private func timeAgo(_ date: Date) -> String {
        let seconds = Int(-date.timeIntervalSinceNow)
        if seconds < 3600 { return "\(seconds / 60)m ago" }
        if seconds < 86400 { return "\(seconds / 3600)h ago" }
        return "\(seconds / 86400)d ago"
    }
}

// Extension to add color to category
extension MarketCategory {
    var color: Color {
        switch self {
        case .textbooks: return .blue
        case .services: return .purple
        case .electronics: return .green
        case .transport: return .orange
        case .other: return .gray
        }
    }
}

// Simple ZStack alias to handle the background/foreground layers
struct ZESack<Content: View>: View {
    let content: Content
    
    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }
    
    var body: some View {
        ZStack {
            content
        }
    }
}
