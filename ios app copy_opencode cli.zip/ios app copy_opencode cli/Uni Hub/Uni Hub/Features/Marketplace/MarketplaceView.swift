import SwiftUI

struct MarketplaceView: View {
    @StateObject private var store = MarketplaceStore.shared
    @State private var selectedCategory: MarketCategory? = nil
    @State private var searchText = ""
    
    var body: some View {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    // Header Section
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Student Marketplace")
                            .font(.system(size: 28, weight: .black))
                        Text("Benefits by students, for students.")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                    .padding(.horizontal)
                    
                    // Categories Scroll
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 12) {
                            MarketCategoryChip(label: "All", icon: "square.grid.2x2.fill", isActive: selectedCategory == nil) {
                                selectedCategory = nil
                            }
                            
                            ForEach(MarketCategory.allCases) { category in
                                MarketCategoryChip(
                                    label: category.rawValue,
                                    icon: category.icon,
                                    isActive: selectedCategory == category
                                ) {
                                    selectedCategory = category
                                }
                            }
                        }
                        .padding(.horizontal)
                    }
                    
                    // "Recommended for You" - Hero Section
                    if selectedCategory == nil && searchText.isEmpty {
                        VStack(alignment: .leading, spacing: 12) {
                            HStack {
                                Text("Recommended for You")
                                    .font(.system(size: 20, weight: .bold))
                                Spacer()
                                Button("See All") {}
                                    .font(.caption)
                                    .foregroundColor(.accentColor)
                            }
                            .padding(.horizontal)
                            
                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack(spacing: 16) {
                                    ForEach(store.listings.filter { $0.isPromoted }) { listing in
                                        MarketListingCard(listing: listing)
                                            .frame(width: 280)
                                    }
                                }
                                .padding(.horizontal)
                            }
                        }
                    }
                    
                    // Main Feed
                    VStack(alignment: .leading, spacing: 15) {
                        Text(selectedCategory?.rawValue ?? "Recent Listings")
                            .font(.system(size: 20, weight: .bold))
                            .padding(.horizontal)
                        
                        let filtered = store.listings(for: selectedCategory)
                            .filter { searchText.isEmpty || $0.title.localizedCaseInsensitiveContains(searchText) }
                        
                        if filtered.isEmpty {
                            VStack(spacing: 12) {
                                Image(systemName: "bag.badge.questionmark")
                                    .font(.system(size: 40))
                                    .foregroundColor(.secondary)
                                Text("No listings found")
                                    .font(.headline)
                                Text("Try adjusting your filters or search.")
                                    .font(.subheadline)
                                    .foregroundColor(.secondary)
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 40)
                        } else {
                            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 16) {
                                ForEach(filtered) { listing in
                                    MarketListingCard(listing: listing)
                                }
                            }
                            .padding(.horizontal)
                        }
                    }
                }
                .padding(.vertical)
            }
            .searchable(text: $searchText, prompt: "Search textbooks, services...")
            .background(Color(.systemBackground))
    }
}

struct MarketCategoryChip: View {
    let label: String
    let icon: String
    let isActive: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 6) {
                Image(systemName: icon)
                    .font(.system(size: 14, weight: .semibold))
                Text(label)
                    .font(.system(size: 14, weight: .bold))
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
            .background(isActive ? Color.accentColor : Color(.secondarySystemBackground))
            .foregroundColor(isActive ? .white : .primary)
            .cornerRadius(12)
            .shadow(color: isActive ? Color.accentColor.opacity(0.3) : Color.clear, radius: 8, x: 0, y: 4)
        }
        .buttonStyle(.plain)
    }
}
