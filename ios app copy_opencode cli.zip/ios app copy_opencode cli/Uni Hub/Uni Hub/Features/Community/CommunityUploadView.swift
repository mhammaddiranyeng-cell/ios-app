import SwiftUI

struct CommunityUploadView: View {
    @Environment(\.dismiss) var dismiss
    @ObservedObject private var store = CommunityStore.shared
    private let dataStore = UniversityDataStore.shared

    // Step state
    @State private var selectedMaterial: MaterialType = .notes
    @State private var courseCode: String = ""
    @State private var courseName: String = ""
    @State private var title: String = ""
    @State private var description: String = ""

    // University hierarchy selection
    @State private var selectedUniversity: LBUniversity? = nil
    @State private var selectedFaculty: LBFaculty? = nil
    @State private var selectedMajor: LBMajor? = nil

    // Validation
    @State private var showValidationAlert = false
    @State private var validationMessage = ""

    var body: some View {
        NavigationView {
            Form {
                // MARK: - Material Type
                Section(header: Label("What are you uploading?", systemImage: "doc.badge.plus")) {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 10) {
                            ForEach(MaterialType.allCases) { type in
                                MaterialTypePill(type: type, isSelected: selectedMaterial == type)
                                    .onTapGesture { selectedMaterial = type }
                            }
                        }
                        .padding(.vertical, 4)
                    }
                }

                // MARK: - University Hierarchy
                Section(header: Label("Your University", systemImage: "building.columns")) {
                    Picker("University", selection: $selectedUniversity) {
                        Text("Select University").tag(Optional<LBUniversity>(nil))
                        ForEach(dataStore.universities) { uni in
                            Text(uni.shortCode).tag(Optional(uni))
                        }
                    }
                    .onChange(of: selectedUniversity) { _ in
                        selectedFaculty = nil
                        selectedMajor = nil
                    }

                    if let uni = selectedUniversity {
                        Picker("Faculty", selection: $selectedFaculty) {
                            Text("Select Faculty").tag(Optional<LBFaculty>(nil))
                            ForEach(uni.faculties) { fac in
                                Text(fac.name).tag(Optional(fac))
                            }
                        }
                        .onChange(of: selectedFaculty) { _ in selectedMajor = nil }
                    }

                    if let fac = selectedFaculty {
                        Picker("Major", selection: $selectedMajor) {
                            Text("Select Major").tag(Optional<LBMajor>(nil))
                            ForEach(fac.majors) { major in
                                Text(major.name).tag(Optional(major))
                            }
                        }
                    }
                }

                // MARK: - Course Info
                Section(header: Label("Course Details", systemImage: "book.closed")) {
                    HStack {
                        Image(systemName: "number")
                            .foregroundColor(.secondary)
                        TextField("Course Code (e.g. EECE 330)", text: $courseCode)
                            .autocapitalization(.allCharacters)
                    }
                    HStack {
                        Image(systemName: "textformat")
                            .foregroundColor(.secondary)
                        TextField("Course Name (e.g. Control Systems)", text: $courseName)
                    }
                }

                // MARK: - Document Info
                Section(header: Label("Document Info", systemImage: "doc.text")) {
                    TextField("Title", text: $title)
                    TextField("Description (optional)", text: $description, axis: .vertical)
                        .lineLimit(3...6)
                }

                // MARK: - File (placeholder for future Supabase)
                Section(header: Label("File", systemImage: "paperclip")) {
                    Button {
                        // Future: UIDocumentPickerViewController
                    } label: {
                        Label("Select File (PDF, DOCX…)", systemImage: "folder.badge.plus")
                            .foregroundColor(.blue)
                    }
                    Text("File upload will be connected to Supabase in v2.")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            .navigationTitle("Share Resource")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Submit") { submit() }
                        .fontWeight(.semibold)
                }
            }
            .alert("Please fix the following", isPresented: $showValidationAlert) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(validationMessage)
            }
        }
    }

    // MARK: - Submit

    private func submit() {
        guard let uni = selectedUniversity else {
            validate("Please select your university.")
            return
        }
        guard let faculty = selectedFaculty else {
            validate("Please select your faculty.")
            return
        }
        guard let major = selectedMajor else {
            validate("Please select your major.")
            return
        }
        guard !title.trimmingCharacters(in: .whitespaces).isEmpty else {
            validate("Please enter a title for your document.")
            return
        }
        guard !courseCode.isEmpty || !courseName.isEmpty else {
            validate("Please enter at least a course code or course name.")
            return
        }

        let post = CommunityPost(
            id: UUID(),
            uploaderName: "You",
            universityName: uni.name,
            facultyName: faculty.name,
            majorName: major.name,
            courseCode: courseCode.trimmingCharacters(in: .whitespaces),
            courseName: courseName.trimmingCharacters(in: .whitespaces),
            materialType: selectedMaterial,
            title: title.trimmingCharacters(in: .whitespaces),
            description: description.trimmingCharacters(in: .whitespaces),
            uploadedAt: Date()
        )
        store.add(post: post)
        dismiss()
    }

    private func validate(_ msg: String) {
        validationMessage = msg
        showValidationAlert = true
    }
}

// MARK: - Material Type Pill

struct MaterialTypePill: View {
    let type: MaterialType
    let isSelected: Bool

    var body: some View {
        HStack(spacing: 5) {
            Image(systemName: type.icon)
            Text(type.rawValue)
                .font(.subheadline.weight(.semibold))
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 8)
        .background(isSelected ? type.color : Color(.systemGray5))
        .foregroundColor(isSelected ? .white : .primary)
        .clipShape(Capsule())
        .animation(.easeInOut(duration: 0.2), value: isSelected)
    }
}
