import SwiftUI

// MARK: - Main Community View

struct CommunityView: View {
    @StateObject private var store = CommunityStore.shared
    private let dataStore = UniversityDataStore.shared

    @State private var searchText = ""
    @State private var selectedUniversity: LBUniversity? = nil
    @State private var selectedFaculty: LBFaculty? = nil
    @State private var selectedMajor: LBMajor? = nil
    @State private var showUpload = false

    // Filtered posts based on hierarchy + search
    var filteredPosts: [CommunityPost] {
        var result = store.posts

        if let uni = selectedUniversity {
            result = result.filter { $0.universityName == uni.name }
        }
        if let fac = selectedFaculty {
            result = result.filter { $0.facultyName == fac.name }
        }
        if let maj = selectedMajor {
            result = result.filter { $0.majorName == maj.name }
        }

        return store.search(query: searchText, in: result)
    }

    var body: some View {
        VStack(spacing: 0) {
            // Hierarchy filter bar
            HierarchyFilterBar(
                dataStore: dataStore,
                selectedUniversity: $selectedUniversity,
                selectedFaculty: $selectedFaculty,
                selectedMajor: $selectedMajor
            )

            Divider()

            // Posts list or empty state
            if filteredPosts.isEmpty {
                CommunityEmptyState(searchText: searchText, hasFilters: selectedUniversity != nil)
            } else {
                List {
                    ForEach(filteredPosts) { post in
                        CommunityPostCard(post: post)
                            .listRowInsets(EdgeInsets(top: 8, leading: 16, bottom: 8, trailing: 16))
                            .listRowSeparator(.hidden)
                    }
                }
                .listStyle(.plain)
            }
        }
        .searchable(text: $searchText, prompt: "Search exams, notes, courses…")
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button {
                    showUpload = true
                } label: {
                    Image(systemName: "plus.circle.fill")
                        .font(.title2)
                }
            }
        }
        .sheet(isPresented: $showUpload) {
            CommunityUploadView()
        }
    }
}

// MARK: - Hierarchy Filter Bar

struct HierarchyFilterBar: View {
    let dataStore: UniversityDataStore
    @Binding var selectedUniversity: LBUniversity?
    @Binding var selectedFaculty: LBFaculty?
    @Binding var selectedMajor: LBMajor?

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                // University picker
                FilterChip(
                    label: selectedUniversity?.shortCode ?? "University",
                    isActive: selectedUniversity != nil,
                    icon: "building.columns"
                ) {
                    // Handled via sheet/menu below
                }
                .contextMenu {
                    Button("All Universities") {
                        selectedUniversity = nil
                        selectedFaculty = nil
                        selectedMajor = nil
                    }
                    Divider()
                    ForEach(dataStore.universities) { uni in
                        Button(uni.shortCode) {
                            selectedUniversity = uni
                            selectedFaculty = nil
                            selectedMajor = nil
                        }
                    }
                }

                // Faculty picker (only shown if university selected)
                if let uni = selectedUniversity {
                    Image(systemName: "chevron.right")
                        .font(.caption)
                        .foregroundColor(.secondary)

                    FilterChip(
                        label: selectedFaculty?.name.replacingOccurrences(of: "Faculty of ", with: "")
                              .replacingOccurrences(of: "School of ", with: "")
                              .replacingOccurrences(of: "College of ", with: "") ?? "Faculty",
                        isActive: selectedFaculty != nil,
                        icon: "person.3"
                    ) {}
                    .contextMenu {
                        Button("All Faculties") {
                            selectedFaculty = nil
                            selectedMajor = nil
                        }
                        Divider()
                        ForEach(uni.faculties) { fac in
                            Button(fac.name) {
                                selectedFaculty = fac
                                selectedMajor = nil
                            }
                        }
                    }
                }

                // Major picker (only shown if faculty selected)
                if let fac = selectedFaculty {
                    Image(systemName: "chevron.right")
                        .font(.caption)
                        .foregroundColor(.secondary)

                    FilterChip(
                        label: selectedMajor?.name ?? "Major",
                        isActive: selectedMajor != nil,
                        icon: "graduationcap"
                    ) {}
                    .contextMenu {
                        Button("All Majors") { selectedMajor = nil }
                        Divider()
                        ForEach(fac.majors) { major in
                            Button(major.name) { selectedMajor = major }
                        }
                    }
                }

                Spacer()
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
        }
        .background(Color(.systemBackground))
    }
}

// MARK: - Filter Chip

struct FilterChip: View {
    let label: String
    let isActive: Bool
    let icon: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 4) {
                Image(systemName: icon)
                    .font(.caption)
                Text(label)
                    .font(.subheadline.weight(.medium))
                    .lineLimit(1)
                Image(systemName: "chevron.down")
                    .font(.caption2)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 7)
            .background(isActive ? Color.accentColor : Color(.systemGray5))
            .foregroundColor(isActive ? .white : .primary)
            .clipShape(Capsule())
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Community Post Card

struct CommunityPostCard: View {
    let post: CommunityPost

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            // Header row
            HStack(alignment: .top) {
                // Material type badge
                HStack(spacing: 5) {
                    Image(systemName: post.materialType.icon)
                        .font(.caption2.weight(.bold))
                    Text(post.materialType.rawValue.uppercased())
                        .font(.caption2.weight(.bold))
                        .kerning(0.5)
                }
                .padding(.horizontal, 8)
                .padding(.vertical, 4)
                .background(post.materialType.color.opacity(0.15))
                .foregroundColor(post.materialType.color)
                .clipShape(Capsule())

                Spacer()

                Text(timeAgo(post.uploadedAt))
                    .font(.caption)
                    .foregroundColor(.secondary)
            }

            // Title
            Text(post.title)
                .font(.headline)
                .lineLimit(2)

            // Course label
            if post.courseLabel != "General" {
                HStack(spacing: 4) {
                    Image(systemName: "book.closed")
                        .font(.caption)
                    Text(post.courseLabel)
                        .font(.subheadline)
                }
                .foregroundColor(.accentColor)
            }

            // Description
            if !post.description.isEmpty {
                Text(post.description)
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .lineLimit(2)
            }

            Divider()

            // Footer
            HStack {
                Image(systemName: "graduationcap.fill")
                    .font(.caption2)
                    .foregroundColor(.secondary)
                Text(post.majorName)
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .lineLimit(1)
                Spacer()
                Image(systemName: "person.fill")
                    .font(.caption2)
                    .foregroundColor(.secondary)
                Text(post.uploaderName)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
        .padding()
        .background(Color(.secondarySystemBackground))
        .cornerRadius(14)
    }

    private func timeAgo(_ date: Date) -> String {
        let seconds = Int(-date.timeIntervalSinceNow)
        if seconds < 3600 { return "\(seconds / 60)m ago" }
        if seconds < 86400 { return "\(seconds / 3600)h ago" }
        return "\(seconds / 86400)d ago"
    }
}

// MARK: - Empty State

struct CommunityEmptyState: View {
    let searchText: String
    let hasFilters: Bool

    var body: some View {
        VStack(spacing: 16) {
            Image(systemName: searchText.isEmpty ? "person.3" : "magnifyingglass")
                .font(.system(size: 48))
                .foregroundColor(.secondary.opacity(0.5))

            Text(searchText.isEmpty
                 ? (hasFilters ? "No posts yet for this filter" : "No community posts yet")
                 : "No results for \"\(searchText)\"")
                .font(.headline)
                .multilineTextAlignment(.center)

            Text("Be the first to share an exam, quiz, or notes!")
                .font(.subheadline)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
        }
        .padding(40)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

