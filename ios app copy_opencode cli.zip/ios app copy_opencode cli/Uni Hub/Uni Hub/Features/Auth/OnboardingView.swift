import SwiftUI

struct OnboardingView: View {
    @EnvironmentObject var authManager: AuthManager
    @EnvironmentObject var appState: AppState
    
    var body: some View {
        NavigationView {
            VStack(spacing: 30) {
                Spacer()
                
                VStack(spacing: 20) {
                    Image(systemName: "graduationcap.fill")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 100, height: 100)
                        .foregroundColor(.blue)
                        .shadow(color: Color.blue.opacity(0.2), radius: 20, x: 0, y: 10)
                    
                    Text("Student Hub Lebanon")
                        .font(.largeTitle)
                        .bold()
                        .multilineTextAlignment(.center)
                    
                    Text("Your courses, notes, deadlines, and campus life in one place.")
                        .font(.body)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                }
                
                Spacer()
                
                VStack(spacing: 20) {
                    Text("Sign in or create an account to get started")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    NavigationLink(destination: EmailAuthView()) {
                        HStack {
                            Image(systemName: "envelope.fill")
                                .frame(width: 20)
                            Text("Sign in with Email")
                                .bold()
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(14)
                        .shadow(color: Color.blue.opacity(0.3), radius: 10, x: 0, y: 5)
                    }
                    
                    Button(action: {
                        appState.enableGuestMode()
                    }) {
                        HStack {
                            Image(systemName: "person.crop.circle")
                                .frame(width: 20)
                            Text("Continue as Guest")
                                .bold()
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color(.systemGray5))
                        .foregroundColor(.primary)
                        .cornerRadius(14)
                    }
                    
                    Text("By continuing, you agree to our Terms of Service and Privacy Policy")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 20)
                }
                .padding(.horizontal, 30)
                .padding(.bottom, 40)
            }
        }
    }
}
