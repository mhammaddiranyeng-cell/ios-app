import SwiftUI

struct EmailAuthView: View {
    @EnvironmentObject var authManager: AuthManager
    @Environment(\.dismiss) var dismiss
    
    @State private var email = ""
    @State private var password = ""
    @State private var confirmPassword = ""
    @State private var otpCode = ""
    @State private var isSignUp = false
    @State private var isAwaitingOTP = false
    @State private var isLoading = false
    @State private var errorMessage: String?
    @State private var showPassword = false
    
    var body: some View {
        VStack(spacing: 25) {
            VStack(spacing: 10) {
                Text(isAwaitingOTP ? "Verify Email" : (isSignUp ? "Create Account" : "Welcome Back"))
                    .font(.system(size: 32, weight: .black))
                
                Text(isAwaitingOTP ? "Enter the 6-digit code sent to your email." : (isSignUp ? "Create your account and verify your email." : "Sign in to access your dashboard."))
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
            }
            .padding(.top, 40)
            
            VStack(spacing: 15) {
                if isAwaitingOTP {
                    CustomAuthField(icon: "number", placeholder: "6-Digit Code", text: $otpCode)
                        .keyboardType(.numberPad)
                } else {
                    CustomAuthField(icon: "envelope.fill", placeholder: "Email", text: $email)
                        .keyboardType(.emailAddress)
                        .autocapitalization(.none)
                    
                    CustomAuthField(icon: "lock.fill", placeholder: "Password", text: $password, isSecure: !showPassword)
                    
                    if isSignUp {
                        CustomAuthField(icon: "lock.fill", placeholder: "Confirm Password", text: $confirmPassword, isSecure: !showPassword)
                        
                        Toggle(isOn: $showPassword) {
                            Text(showPassword ? "Hide Password" : "Show Password")
                                .font(.caption)
                                .foregroundColor(.blue)
                        }
                        .toggleStyle(.switch)
                    }
                }
            }
            .padding(.top, 20)
            
            if let error = errorMessage {
                Text(error)
                    .font(.caption)
                    .foregroundColor(.red)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
            }
            
            Button(action: handleAuth) {
                HStack {
                    if isLoading {
                        ProgressView()
                            .progressViewStyle(CircularProgressViewStyle(tint: .white))
                            .padding(.trailing, 10)
                    }
                    Text(isAwaitingOTP ? "Verify Code" : (isSignUp ? "Create Account" : "Sign In"))
                        .bold()
                }
                .frame(maxWidth: .infinity)
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(14)
                .shadow(color: Color.blue.opacity(0.3), radius: 10, x: 0, y: 5)
            }
            .disabled(isLoading || isValidatingForm)
            .padding(.top, 10)
            
            if !isAwaitingOTP {
                Button(action: { isSignUp.toggle() }) {
                    Text(isSignUp ? "Already have an account? Sign In" : "Don't have an account? Sign Up")
                        .font(.footnote)
                        .foregroundColor(.blue)
                }
            } else {
                Button(action: { isAwaitingOTP = false; otpCode = "" }) {
                    Text("Go back and try again")
                        .font(.footnote)
                        .foregroundColor(.secondary)
                }
            }
            
            Spacer()
        }
        .padding(30)
        .navigationBarTitleDisplayMode(.inline)
        .onChange(of: isSignUp) { _ in
            errorMessage = nil
            confirmPassword = ""
        }
    }
    
    var isValidatingForm: Bool {
        if isAwaitingOTP {
            return otpCode.count != 6
        } else if isSignUp {
            return email.isEmpty || password.isEmpty || confirmPassword.isEmpty || password != confirmPassword
        } else {
            return email.isEmpty || password.isEmpty
        }
    }
    
    func handleAuth() {
        isLoading = true
        errorMessage = nil
            
        Task {
            do {
                if isAwaitingOTP {
                    try await authManager.verifyOTP(email: email, token: otpCode)
                    dismiss()
                } else if isSignUp {
                    if password != confirmPassword {
                        errorMessage = "Passwords do not match"
                        isLoading = false
                        return
                    }
                    if password.count < 6 {
                        errorMessage = "Password must be at least 6 characters"
                        isLoading = false
                        return
                    }
                    // First sign up the user
                    try await authManager.signUp(email: email, password: password)
                    // Then automatically request OTP for verification
                    try await authManager.requestOTP(email: email)
                    isAwaitingOTP = true
                    errorMessage = nil
                } else {
                    try await authManager.signIn(email: email, password: password)
                    dismiss()
                }
            } catch {
                let errString = error.localizedDescription
                // If it's a 400 error (Invalid login credentials) and we are trying to sign in,
                // the user might just be unverified. We can try to request a new OTP for them!
                if !isSignUp && !isAwaitingOTP && (errString.contains("400") || errString.contains("Invalid login credentials") || errString.contains("Email not confirmed")) {
                    do {
                        try await authManager.requestOTP(email: email)
                        isAwaitingOTP = true
                        errorMessage = "Account not verified. A new code was sent to your email."
                    } catch {
                        errorMessage = error.localizedDescription
                    }
                } else {
                    errorMessage = errString
                }
            }
            isLoading = false
        }
    }
}

struct CustomAuthField: View {
    let icon: String
    let placeholder: String
    @Binding var text: String
    var isSecure: Bool = false
    
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .foregroundColor(.secondary)
                .frame(width: 20)
            
            if isSecure {
                SecureField(placeholder, text: $text)
            } else {
                TextField(placeholder, text: $text)
            }
        }
        .padding()
        .background(Color(.secondarySystemBackground))
        .cornerRadius(12)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(Color.primary.opacity(0.1), lineWidth: 1.5)
        )
        .shadow(color: Color.black.opacity(0.02), radius: 2, x: 0, y: 1)
    }
}

struct EmailAuthView_Previews: PreviewProvider {
    static var previews: some View {
        EmailAuthView()
            .environmentObject(AuthManager())
    }
}
