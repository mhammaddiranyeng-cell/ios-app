import SwiftUI

struct CourseListView: View {
    @State private var courses: [Course] = []
    @State private var isLoading = false
    @State private var searchText = ""
    
    var body: some View {
        NavigationView {
            List {
                if isLoading {
                    ProgressView("Loading Courses...")
                } else {
                    Section(header: Text("My Courses")) {
                        ForEach(courses) { course in
                            NavigationLink(destination: CourseDetailView(courseName: course.title)) {
                                VStack(alignment: .leading) {
                                    Text(course.code).font(.caption).bold()
                                    Text(course.title)
                                }
                            }
                        }
                    }
                }
                
                Section(header: Text("Browse Universities")) {
                    ForEach(UniversityDataStore.shared.universities.prefix(5)) { uni in
                        NavigationLink(destination: Text("\(uni.name) Courses coming soon...")) {
                            HStack {
                                Image(systemName: "building.columns")
                                    .foregroundColor(.accentColor)
                                Text(uni.shortCode)
                                    .font(.subheadline.weight(.medium))
                                Spacer()
                                Text("\(uni.faculties.count) Faculties")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                        }
                    }
                    NavigationLink(destination: CommunityView()) {
                        Text("Explore All in Community Hub")
                            .font(.subheadline)
                            .foregroundColor(.accentColor)
                    }
                }
            }
            .navigationTitle("Courses")
            .searchable(text: $searchText, prompt: "Search course code, name...")
            .task {
                await loadCourses()
            }
            .refreshable {
                await loadCourses()
            }
        }
    }
    
    func loadCourses() async {
        isLoading = true
        do {
            self.courses = try await DatabaseManager.shared.fetchCourses()
        } catch {
            print("Error loading courses: \(error)")
        }
        isLoading = false
    }
}

struct CourseDetailView: View {
    let courseName: String
    @State private var showingUploadSheet = false
    
    var body: some View {
        List {
            Section(header: Text("Notes & Resources")) {
                NoteRow(title: "Midterm Summary - Chapter 1-5", uploader: "Ahmad K.", type: .pdf)
                NoteRow(title: "Lecture 10 Slides", uploader: "Prof. Smith", type: .slides)
            }
            
            Section {
                Button(action: { showingUploadSheet = true }) {
                    Label("Upload Resource", systemImage: "arrow.up.doc")
                }
            }
        }
        .navigationTitle(courseName)
        .sheet(isPresented: $showingUploadSheet) {
            UploadNoteView()
        }
    }
}

enum FileType {
    case pdf, slides, document
}

struct NoteRow: View {
    let title: String
    let uploader: String
    let type: FileType
    
    var body: some View {
        HStack {
            Image(systemName: type == .pdf ? "doc.fill" : "doc.richtext")
                .foregroundColor(.blue)
            VStack(alignment: .leading) {
                Text(title)
                    .font(.subheadline)
                Text("Uploaded by \(uploader)")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            Spacer()
            Menu {
                Button("Download", action: {})
                Button("Save", action: {})
                Button(role: .destructive, action: {}) {
                    Label("Report", systemImage: "exclamationmark.bubble")
                }
            } label: {
                Image(systemName: "ellipsis")
                    .padding()
            }
        }
    }
}

struct UploadNoteView: View {
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Resource Details")) {
                    TextField("Title", text: .constant(""))
                    TextField("Description", text: .constant(""))
                    Picker("Semester", selection: .constant("Fall 2026")) {
                        Text("Fall 2026").tag("Fall 2026")
                    }
                }
                
                Section {
                    Button("Select File...") {
                        // File picker logic
                    }
                }
            }
            .navigationTitle("Upload Note")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Upload") { dismiss() }
                }
            }
        }
    }
}
