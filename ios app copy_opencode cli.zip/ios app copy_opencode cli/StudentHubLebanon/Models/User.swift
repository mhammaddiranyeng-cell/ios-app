import Foundation

struct User: Codable, Identifiable {
    let id: UUID
    let email: String
    var fullName: String?
    var universityId: UUID?
    var facultyId: UUID?
    var role: UserRole
    var isPro: Bool
    var proExpiresAt: Date?
    
    enum CodingKeys: String, CodingKey {
        case id, email, role
        case fullName = "full_name"
        case universityId = "university_id"
        case facultyId = "faculty_id"
        case isPro = "is_pro"
        case proExpiresAt = "pro_expires_at"
    }
}

enum UserRole: String, Codable {
    case guest, student, tutor, moderator, admin
}
