import Foundation

struct Course: Codable, Identifiable {
    let id: UUID
    let facultyId: UUID
    let code: String
    let title: String
    var description: String?
    var credits: Int?
    
    enum CodingKeys: String, CodingKey {
        case id, code, title, description, credits
        case facultyId = "faculty_id"
    }
}
