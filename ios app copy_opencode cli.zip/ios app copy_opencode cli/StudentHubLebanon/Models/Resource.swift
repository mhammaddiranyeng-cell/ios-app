import Foundation

struct Resource: Codable, Identifiable {
    let id: UUID
    let courseId: UUID
    let uploaderId: UUID?
    let title: String
    var description: String?
    let fileUrl: String
    var fileType: String?
    var semester: String?
    var isHidden: Bool
    let createdAt: Date
    
    enum CodingKeys: String, CodingKey {
        case id, title, description, semester
        case courseId = "course_id"
        case uploaderId = "uploader_id"
        case fileUrl = "file_url"
        case fileType = "file_type"
        case isHidden = "is_hidden"
        case createdAt = "created_at"
    }
}
