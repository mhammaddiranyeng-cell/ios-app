# App Store Compliance & MVP Guidelines

## 1. App Store Requirements Checklist
- [x] **No In-App Digital Goods via Stripe:** Tutoring uses lead gen (messaging requests). Textbook marketplace trades physical books. Notes are free. This entirely skips App Store 30% cut constraints.
- [x] **StoreKit 2 Integration:** Used ONLY for Pro Tier unlocking features (No Ads, Offline Library, AI features). 
- [x] **UGC Safety:** Reporting capabilities on listings, notes, tutors, and user profiles. Built in block-list functionality.
- [x] **Sign In with Apple:** Present, required if Google Auth is used.
- [x] **Account Deletion:** Explicit deletion flow built into `SettingsView`. Soft/hard DB delete protocol ready.
- [x] **Privacy Policy & Terms:** Placeholders in `SettingsView`, to be hosted simply later.

## 2. Monetization Implementation
**StoreKit:**
- Products: `studenthub.pro.monthly`, `studenthub.pro.yearly`.
- Use StoreKit 2 `Product.products(for:)`.
- Handle `Transaction.updates` async stream.

**AdMob:**
- Google UMP configured for consent.
- ATT tracking authorization wrapped correctly.
- Implement Ads wrapper conditionally: `if !userManager.isPro { NativeAd() }`.

## 3. Reporting & Blocking Rules
- Items reported > 3 times automatically hidden pending admin review.
- Notes reported for copyright automatically hidden pending verification.
- Users who block someone will not see their events, Marketplace listings, notes, or planner shared items.

**Production MVP Focus:** Provide core functionality (Courses, Notes, Planner) to hook students first. Wait on AI functionality if backend costs escalate, fallback to simpler ad-monetization.
