import Foundation
import StoreKit

@MainActor
class SubscriptionManager: ObservableObject {
    @Published var isPro: Bool = false
    @Published var products: [Product] = []
    
    private let productIds = ["studenthub.pro.monthly", "studenthub.pro.yearly"]
    
    init() {
        // In a real app, listen to Transaction.updates here
        Task {
            await fetchProducts()
            await checkActiveEntitlements()
        }
    }
    
    func fetchProducts() async {
        do {
            products = try await Product.products(for: productIds)
        } catch {
            print("Failed to fetch products: \(error)")
        }
    }
    
    func checkActiveEntitlements() async {
        // Iterate through Transaction.currentEntitlements
        // If an active one is found, set isPro = true
    }
    
    func purchase(_ product: Product) async throws {
        let result = try await product.purchase()
        
        switch result {
        case .success(let verification):
            // Check verification, grant entitlement
            isPro = true
        case .userCancelled, .pending:
            break
        @unknown default:
            break
        }
    }
    
    func restorePurchases() async {
        try? await AppStore.sync()
        await checkActiveEntitlements()
    }
}
