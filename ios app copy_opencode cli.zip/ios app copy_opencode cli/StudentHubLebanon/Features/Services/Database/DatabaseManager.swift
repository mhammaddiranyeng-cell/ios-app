import Foundation

class DatabaseManager {
    static let shared = DatabaseManager()
    
    // Mock Supabase Client Wrapper
    
    func fetchCourses() async throws -> [Course] {
        // Return dummy data for UI testing
        return [
            Course(id: "1", code: "CSCI 200", title: "Data Structures"),
            Course(id: "2", code: "MATH 201", title: "Calculus III")
        ]
    }
    
    func uploadDocument(data: Data, url: URL) async throws -> String {
        // Upload to Supabase Storage
        // Insert record to course_resources table
        return "storage.url"
    }
    
    func reportContent(entityType: String, entityId: String, reason: String) async throws {
        // Insert to reports table
    }
}

struct Course: Identifiable {
    let id: String
    let code: String
    let title: String
}
