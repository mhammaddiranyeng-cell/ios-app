import Foundation
import Combine

class AdsManager: ObservableObject {
    @Published var canShowAds: Bool = true
    @Published var hasConsent: Bool = false
    
    func requestConsentAndLoad() {
        // Wrap Google User Messaging Platform (UMP) SDK
        // Check consent status
        // If granted, init AdMob SDK
        // Load initial native and banner ads
        self.hasConsent = true
    }
    
    func disableAds() {
        canShowAds = false
    }
}
