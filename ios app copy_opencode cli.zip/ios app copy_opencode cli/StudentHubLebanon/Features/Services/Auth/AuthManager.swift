import Foundation
import Combine

class AuthManager: ObservableObject {
    @Published var isAuthenticated: Bool = false
    @Published var currentUser: UserProfile?
    
    // Simulate Supabase / Auth Session
    func signInWithApple() {
        // Mock async auth
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            self.isAuthenticated = true
            self.currentUser = UserProfile(id: UUID().uuidString, email: "student@university.edu.lb", name: "Student Name", role: .student)
        }
    }
    
    func signOut() {
        isAuthenticated = false
        currentUser = nil
        // Clear tokens from Keychain
    }
}

struct UserProfile {
    let id: String
    let email: String
    let name: String
    let role: UserRole
}

enum UserRole {
    case guest, student, tutor, moderator, admin
}
