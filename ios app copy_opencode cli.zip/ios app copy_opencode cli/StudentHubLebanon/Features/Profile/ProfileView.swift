import SwiftUI

struct ProfileView: View {
    @EnvironmentObject var authManager: AuthManager
    
    var body: some View {
        NavigationView {
            List {
                Section {
                    HStack {
                        Image(systemName: "person.circle.fill")
                            .resizable()
                            .frame(width: 60, height: 60)
                            .foregroundColor(.gray)
                        VStack(alignment: .leading) {
                            Text("Student Name")
                                .font(.headline)
                            Text("student@university.edu.lb")
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                        }
                    }
                }
                
                Section(header: Text("Account")) {
                    NavigationLink("Subscription", destination: PaywallView())
                    NavigationLink("Saved Notes", destination: Text("Saved Notes View"))
                    NavigationLink("My Uploads", destination: Text("My Uploads View"))
                }
                
                Section(header: Text("General")) {
                    NavigationLink("Notification Preferences", destination: Text("Notifications"))
                    NavigationLink("Privacy Controls", destination: Text("Privacy"))
                    NavigationLink("Blocked Users", destination: Text("Blocked"))
                }
                
                Section(header: Text("Support")) {
                    Button("Contact Support") { }
                    Link("Terms of Service", destination: URL(string: "https://example.com/terms")!)
                    Link("Privacy Policy", destination: URL(string: "https://example.com/privacy")!)
                }
                
                Section {
                    Button("Sign Out", role: .destructive) {
                        authManager.signOut()
                    }
                    Button("Delete Account", role: .destructive) {
                        // Account deletion flow
                    }
                }
            }
            .navigationTitle("Profile")
        }
    }
}

// Simple paywall scaffold
struct PaywallView: View {
    var body: some View {
        VStack(spacing: 20) {
            Text("Student Hub Pro")
                .font(.largeTitle)
                .bold()
            
            Text("Unlock your full academic potential.")
                .font(.subheadline)
            
            VStack(alignment: .leading, spacing: 10) {
                Label("No Ads", systemImage: "checkmark.circle.fill")
                Label("Unlimited Offline Downloads", systemImage: "checkmark.circle.fill")
                Label("AI Summaries & Flashcards", systemImage: "checkmark.circle.fill")
                Label("Advanced Planner Insights", systemImage: "checkmark.circle.fill")
            }
            .padding()
            
            Spacer()
            
            Button("Subscribe Monthly - $X.XX") { }
                .buttonStyle(.borderedProminent)
            Button("Subscribe Yearly - $Y.YY") { }
                .buttonStyle(.borderedProminent)
            
            Button("Restore Purchases") { }
                .padding()
        }
        .padding()
        .navigationTitle("Upgrade")
        .navigationBarTitleDisplayMode(.inline)
    }
}
