import SwiftUI

struct HomeView: View {
    @EnvironmentObject var adsManager: AdsManager
    @EnvironmentObject var subscriptionManager: SubscriptionManager
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    
                    // Welcome Header
                    HStack {
                        VStack(alignment: .leading) {
                            Text("Good morning, Karim 👋")
                                .font(.title)
                                .bold()
                            Text("AUB • Computer Science")
                                .foregroundColor(.secondary)
                        }
                        Spacer()
                    }
                    .padding(.horizontal)
                    
                    // Quick Stats / Deadlines card
                    CardView(title: "Upcoming Deadlines", icon: "exclamationmark.triangle.fill", color: .red) {
                        Text("Software Engineering Final - Toomorrow")
                    }
                    
                    // Saved Notes card
                    CardView(title: "Recent Notes", icon: "doc.text.fill", color: .blue) {
                        Text("Calculus III Midterm Review")
                    }
                    
                    // Pro Upsell (if free user)
                    if !subscriptionManager.isPro {
                        ProUpsellCard()
                    }
                    
                    // Native Ad Placement
                    if !subscriptionManager.isPro {
                        NativeAdView()
                            .frame(height: 100)
                            .padding(.horizontal)
                    }
                }
                .padding(.vertical)
            }
            .navigationTitle("Dashboard")
        }
    }
}

// Scaffolded Pro Upsell Card
struct ProUpsellCard: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Unlock Student Hub Pro")
                .font(.headline)
            Text("No ads, AI Summaries, and unlimited offline downloads.")
                .font(.subheadline)
            Button("Upgrade Now") {
                // Show Paywall
            }
            .buttonStyle(.borderedProminent)
            .tint(.purple)
        }
        .padding()
        .background(Color.purple.opacity(0.1))
        .cornerRadius(12)
        .padding(.horizontal)
    }
}

struct CardView<Content: View>: View {
    let title: String
    let icon: String
    let color: Color
    let content: () -> Content
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Image(systemName: icon)
                    .foregroundColor(color)
                Text(title)
                    .font(.headline)
            }
            content()
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(.systemGray6))
        .cornerRadius(12)
        .padding(.horizontal)
    }
}

// Scaffolded Native Ad View
struct NativeAdView: View {
    var body: some View {
        RoundedRectangle(cornerRadius: 12)
            .fill(Color(.systemGray5))
            .overlay(Text("Ad Placement").foregroundColor(.gray))
    }
}
