import SwiftUI

struct MarketplaceView: View {
    var body: some View {
        NavigationView {
            List {
                Section(header: Text("Physical Textbooks")) {
                    BookListingRow(title: "Introduction to Algorithms, 3rd Ed.", course: "CMPS 280", price: "$40", condition: "Good")
                    BookListingRow(title: "Calculus Early Transcendentals", course: "MATH 201", price: "$20", condition: "Like New")
                }
                
                Section {
                    Button(action: {}) {
                        Label("List a Book", systemImage: "plus.circle")
                    }
                }
            }
            .navigationTitle("Marketplace")
        }
    }
}

struct BookListingRow: View {
    let title: String
    let course: String
    let price: String
    let condition: String
    
    var body: some View {
        HStack(alignment: .top) {
            RoundedRectangle(cornerRadius: 8)
                .fill(Color.gray.opacity(0.3))
                .frame(width: 60, height: 80)
                .overlay(Image(systemName: "book.closed").foregroundColor(.gray))
            
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.headline)
                    .lineLimit(2)
                Text("Course: \(course)")
                    .font(.caption)
                    .foregroundColor(.secondary)
                Text("Condition: \(condition)")
                    .font(.caption)
                    .foregroundColor(.secondary)
                
                Text(price)
                    .font(.subheadline)
                    .bold()
                    .foregroundColor(.green)
                    .padding(.top, 4)
            }
        }
        .padding(.vertical, 4)
    }
}
