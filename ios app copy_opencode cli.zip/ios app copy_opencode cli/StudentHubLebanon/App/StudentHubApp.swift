import SwiftUI

@main
struct StudentHubLebanonApp: App {
    @StateObject private var appState = AppState()
    @StateObject private var authManager = AuthManager()
    @StateObject private var subscriptionManager = SubscriptionManager()
    @StateObject private var adsManager = AdsManager()

    var body: some Scene {
        WindowGroup {
            Group {
                if appState.isAppReady {
                    if authManager.isAuthenticated || appState.isGuestMode {
                        MainTabView()
                    } else {
                        OnboardingView()
                    }
                } else {
                    SplashScreenView()
                }
            }
            .environmentObject(appState)
            .environmentObject(authManager)
            .environmentObject(subscriptionManager)
            .environmentObject(adsManager)
            .onAppear {
                appState.checkInitialState()
            }
        }
    }
}
