import Foundation
import Combine

class AppState: ObservableObject {
    @Published var isAppReady: Bool = false
    @Published var isGuestMode: Bool = false
    @Published var currentTheme: AppTheme = .system

    func checkInitialState() {
        // Mock async init (e.g., checking Supabase, pre-caching models)
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            self.isAppReady = true
        }
    }

    func enableGuestMode() {
        isGuestMode = true
    }
}

enum AppTheme {
    case light, dark, system
}
