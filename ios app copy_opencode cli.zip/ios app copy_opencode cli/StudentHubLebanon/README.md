# Student Hub Lebanon - Blueprint & Architecture

## 1. PRODUCT BLUEPRINT
**Summary:** A “Student OS” for Lebanese universities focusing on organization, resources, and community. Monetized from day one via Ads (Free tier) and a Pro Subscription (ad-free, AI features, advanced tools). Designed to be highly sticky by integrating into the student's weekly routine (deadlines, notes, tutoring). No digital goods sold directly in v1 to ensure App Store compliance.

**Target Users:** Lebanese university students needing a centralized hub for notes, events, deadlines, physical textbooks, and tutoring discovery.

**Monetization Map:**
- **Free Tier:** AdMob (Banner & Native ads, Rewarded unlocks), basic features, limited AI actions, standard search.
- **Pro Tier (StoreKit 2):** $X/month or $Y/year. Ad-free, unlimited note downloads, AI summaries, flashcard generation, offline library, smart planner, premium badge.

**Why it's sticky:** Students constantly need to check deadlines and notes. It replaces multiple disjointed apps (WhatsApp, basic calendar, LMS) with one elegant, native iOS experience.

---

## 2. SYSTEM ARCHITECTURE
- **App Architecture:** MVVM + Clean Architecture (SwiftUI)
- **State Management:** `@StateObject`, `@EnvironmentObject` for global state (Auth, Theme), and Combine/async-await for data flow.
- **Networking:** Native `async/await` wrapping a thin networking client talking to Supabase.
- **Backend:** Supabase (Auth, Postgres DB, Storage for notes/images, RLS for security). Realtime for potential future features.

**Folder Structure:**
```text
StudentHub
├── App/                # App Entry, Global State
├── Core/               # Extensions, UI Components, Theme, Utilities
├── Features/           # MVVM modules (Auth, Home, Courses, Planner, Events, Marketplace, Tutoring, Profile)
├── Services/           # API Clients, Managers (AuthManager, AdsManager, SubsManager, etc.)
└── Models/             # Domain Models
```

---

## 3. SCREEN MAP + USER FLOWS
**Guest Flow:** Launch App -> Browse Public Courses/Events (Ads active) -> Prompt to Sign In for Planner/Uploads.
**Auth Flow:** Welcome -> Sign In with Apple / Email -> Profile Completion (University, Major).
**Student Flow (Home):** Home Feed -> View upcoming deadlines & latest notes -> Explore Marketplace -> View Events.
**Pro Upsell Flow:** Attempt AI Summary or hit usage limit -> Show Paywall -> StoreKit Purchase -> Unlock Feature.
**Reporting/Blocking:** Tap '...' on Note/Listing -> Report -> Send to DB -> Hide locally.

---

## 4. MVP BUILD ORDER
1. **Foundation & Auth:** Supabase setup, Sign in with Apple, Email Auth, User Profile.
2. **Core Navigation & Home:** Tab bar (Home, Courses, Planner, Profile).
3. **Courses & Notes:** Course directory, Storage uploads/downloads, note viewing.
4. **Student Planner:** Local/Remote DB syncing for deadlines.
5. **Monetization integration:** StoreKit 2 paywall + AdMob consent flow (Google UMP) and basic placements.
6. **Marketplace & Tutoring (Lead Gen):** Listings for physical books, request forms for tutors.
7. **Compliance & Polish:** Reporting features, block lists, account deletion, dark mode, accessibility checks.
8. **TestFlight Beta.**

---

## 5. DELIVERABLES HANDOFF
Check the `docs/` folder for DB schemas, Monetization rules, and Compliance checklists.
Check the source code scaffolding in `App/`, `Features/`, `Services/`, and `Core/` directories.
