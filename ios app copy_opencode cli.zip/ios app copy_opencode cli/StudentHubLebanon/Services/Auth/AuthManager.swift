import Foundation
import Combine
import Supabase

class AuthManager: ObservableObject {
    @Published var isAuthenticated: Bool = false
    @Published var currentUser: User?
    
    // In a real app, these would be in a Config or Secrets file
    private let supabase = SupabaseClient(
        supabaseURL: URL(string: "https://dzgthecgkzsgiontbaad.supabase.co")!,
        supabaseKey: "sb_publishable_5R_1g_2nFXa43Ziy2CcWIg_2sKNA6gf"
    )
    
    init() {
        checkSession()
    }
    
    func checkSession() {
        Task {
            do {
                let session = try await supabase.auth.session
                await MainActor.run {
                    self.isAuthenticated = true
                    // Fetch profile here
                }
            } catch {
                await MainActor.run { self.isAuthenticated = false }
            }
        }
    }
    
    func signInWithApple() {
        // Implementation for native Sign in with Apple + Supabase Auth
        // For now, staying as a stub for the user to add their specific IDs
    }
    
    func signOut() {
        Task {
            try? await supabase.auth.signOut()
            await MainActor.run {
                self.isAuthenticated = false
                self.currentUser = nil
            }
        }
    }
}
