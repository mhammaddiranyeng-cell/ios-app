import Foundation
import Supabase

class DatabaseManager {
    static let shared = DatabaseManager()
    
    private let supabase = SupabaseClient(
        supabaseURL: URL(string: "https://dzgthecgkzsgiontbaad.supabase.co")!,
        supabaseKey: "sb_publishable_5R_1g_2nFXa43Ziy2CcWIg_2sKNA6gf"
    )
    
    func fetchCourses() async throws -> [Course] {
        return try await supabase
            .from("courses")
            .select()
            .execute()
            .value
    }
    
    func fetchResources(for courseId: UUID) async throws -> [Resource] {
        return try await supabase
            .from("course_resources")
            .select()
            .eq("course_id", value: courseId)
            .execute()
            .value
    }
    
    func uploadResource(data: Data, fileName: String, courseId: UUID, title: String) async throws {
        // 1. Upload file to Storage Bucket
        let fileURL = try await supabase.storage
            .from("notes")
            .upload(path: "\(courseId)/\(fileName)", file: data)
            
        // 2. Insert record into course_resources table
        try await supabase
            .from("course_resources")
            .insert(fileUrl: fileURL) // Simplified for the scaffold
            .execute()
    }
}
