import SwiftUI

struct MainTabView: View {
    @EnvironmentObject var appState: AppState
    @EnvironmentObject var authManager: AuthManager
    
    var body: some View {
        TabView {
            HomeView()
                .tabItem {
                    Label("Home", systemImage: "house.fill")
                }
            
            CourseListView()
                .tabItem {
                    Label("Courses", systemImage: "books.vertical.fill")
                }
            
            PlannerView()
                .tabItem {
                    Label("Planner", systemImage: "calendar")
                }
            
            MarketplaceView()
                .tabItem {
                    Label("Market", systemImage: "cart.fill")
                }
            
            ProfileView()
                .tabItem {
                    Label("Profile", systemImage: "person.crop.circle")
                }
        }
    }
}
